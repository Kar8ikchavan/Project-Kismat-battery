<?php
require_once 'config/database.php';

// Check if admin exists
$stmt = $pdo->query("SELECT COUNT(*) FROM admins");
$count = $stmt->fetchColumn();

if ($count == 0) {
    // Create new admin with password: admin123
    $username = 'admin';
    $password = password_hash('admin123', PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
    if ($stmt->execute([$username, $password])) {
        echo "Admin user created successfully!<br>";
        echo "Username: admin<br>";
        echo "Password: admin123<br>";
    } else {
        echo "Failed to create admin user.<br>";
    }
} else {
    // Update existing admin password
    $password = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE admins SET password = ? WHERE username = 'admin'");
    if ($stmt->execute([$password])) {
        echo "Admin password updated successfully!<br>";
        echo "Username: admin<br>";
        echo "Password: admin123<br>";
    } else {
        echo "Failed to update admin password.<br>";
    }
}

// Display all admins for verification
echo "<br><strong>Current Admins in Database:</strong><br>";
$admins = $pdo->query("SELECT id, username, password FROM admins")->fetchAll();
foreach($admins as $admin) {
    echo "ID: " . $admin['id'] . " - Username: " . $admin['username'] . " - Hash: " . substr($admin['password'], 0, 20) . "...<br>";
}
?>