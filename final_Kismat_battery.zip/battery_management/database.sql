-- Create Database
CREATE DATABASE IF NOT EXISTS battery_management;
USE battery_management;

-- Admins Table
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert Default Admin (password: admin123)
INSERT INTO admins (username, password) VALUES ('admin', MD5('admin123'))
ON DUPLICATE KEY UPDATE password = MD5('admin123');

-- Sold Batteries Table with UNIQUE constraints
CREATE TABLE IF NOT EXISTS sold_batteries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    battery_type ENUM('2 Wheeler', '4 Wheeler', 'Inverter', 'Other') NOT NULL,
    company VARCHAR(50) NOT NULL,
    model_type VARCHAR(100) NOT NULL,
    serial_number VARCHAR(100) NOT NULL,
    ticket_no VARCHAR(50),
    sell_date DATE NOT NULL,
    warranty_months INT NOT NULL,
    warranty_expiry_date DATE NOT NULL,
    referred_by VARCHAR(100),
    bill_file VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -- UNIQUE CONSTRAINTS
    UNIQUE KEY unique_serial (serial_number),
    UNIQUE KEY unique_ticket (ticket_no),
    UNIQUE KEY unique_model_serial (model_type, serial_number),
    INDEX idx_mobile (mobile),
    INDEX idx_customer (customer_name),
    INDEX idx_warranty_expiry (warranty_expiry_date)
);

-- Replacement History Table
CREATE TABLE IF NOT EXISTS replacement_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    battery_id INT NOT NULL,
    replacement_no INT NOT NULL,
    customer_name VARCHAR(100) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    battery_type VARCHAR(50),
    company VARCHAR(50),
    ticket_no VARCHAR(50),
    old_model_no VARCHAR(100),
    new_model_no VARCHAR(100) NOT NULL,
    old_serial_no VARCHAR(100),
    new_serial_no VARCHAR(100) NOT NULL,
    replacement_date DATE NOT NULL,
    dispatch_date DATE,
    decision ENUM('Pending', 'FWD to COMPANY', 'ONSPOT & FWD TO COMPANY', 'FWD TO OTHER COMPANY') DEFAULT 'Pending',
    query_status ENUM('Solved', 'Return', 'Pending', 'Other') DEFAULT 'Pending',
    remarks TEXT,
    document_file VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -- UNIQUE constraint for new serial numbers in replacements
    UNIQUE KEY unique_new_serial (new_serial_no),
    FOREIGN KEY (battery_id) REFERENCES sold_batteries(id) ON DELETE CASCADE,
    INDEX idx_battery_id (battery_id),
    INDEX idx_mobile (mobile),
    INDEX idx_replacement_date (replacement_date)
);

-- External Replacements Table
CREATE TABLE IF NOT EXISTS external_replacements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    battery_type VARCHAR(50),
    company VARCHAR(50),
    model_type VARCHAR(100),
    serial_number VARCHAR(100),
    warranty_details TEXT,
    problem_description TEXT,
    replacement_notes TEXT,
    bill_file VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -- UNIQUE constraint for external serial numbers
    UNIQUE KEY unique_external_serial (serial_number),
    INDEX idx_mobile (mobile)
);

-- Settings Table
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Add SAP code to settings
INSERT INTO settings (setting_key, setting_value) VALUES 
('sap_code', '')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- Create a trigger to prevent duplicate serial numbers across tables
DELIMITER //
CREATE TRIGGER check_duplicate_serial_before_insert
BEFORE INSERT ON sold_batteries
FOR EACH ROW
BEGIN
    DECLARE serial_exists INT;
    SELECT COUNT(*) INTO serial_exists FROM sold_batteries WHERE serial_number = NEW.serial_number;
    IF serial_exists > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Serial number already exists in sold batteries';
    END IF;
END//
DELIMITER ;