<?php
require_once '../config/database.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    exit('Unauthorized');
}

$type = $_GET['type'] ?? 'sales';
$format = $_GET['format'] ?? 'excel';

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="' . $type . '_report_' . date('Y-m-d') . '.xls"');

if ($type == 'sales') {
    $data = $pdo->query("SELECT id, customer_name, mobile, battery_type, company, model_type, serial_number, sell_date, warranty_expiry_date FROM sold_batteries ORDER BY id DESC")->fetchAll();
    
    echo "ID\tCustomer Name\tMobile\tBattery Type\tCompany\tModel\tSerial No\tSell Date\tWarranty Expiry\n";
    foreach($data as $row) {
        echo $row['id'] . "\t";
        echo $row['customer_name'] . "\t";
        echo $row['mobile'] . "\t";
        echo $row['battery_type'] . "\t";
        echo $row['company'] . "\t";
        echo $row['model_type'] . "\t";
        echo $row['serial_number'] . "\t";
        echo $row['sell_date'] . "\t";
        echo $row['warranty_expiry_date'] . "\n";
    }
} elseif ($type == 'replacements') {
    $data = $pdo->query("SELECT id, customer_name, mobile, replacement_no, new_model_no, new_serial_no, replacement_date, decision, query_status FROM replacement_history ORDER BY id DESC")->fetchAll();
    
    echo "ID\tCustomer Name\tMobile\tReplacement No\tNew Model\tNew Serial\tDate\tDecision\tStatus\n";
    foreach($data as $row) {
        echo $row['id'] . "\t";
        echo $row['customer_name'] . "\t";
        echo $row['mobile'] . "\t";
        echo $row['replacement_no'] . "\t";
        echo $row['new_model_no'] . "\t";
        echo $row['new_serial_no'] . "\t";
        echo $row['replacement_date'] . "\t";
        echo $row['decision'] . "\t";
        echo $row['query_status'] . "\n";
    }
}
?>