<?php
session_start();

$host = 'localhost';
$dbname = 'battery_management';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['admin_id']);
}

// Function to redirect if not logged in
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

// Function to calculate warranty expiry date
function calculateExpiryDate($sellDate, $warrantyMonths) {
    return date('Y-m-d', strtotime("+$warrantyMonths months", strtotime($sellDate)));
}

// Function to get warranty status
function getWarrantyStatus($expiryDate) {
    $today = date('Y-m-d');
    if ($today <= $expiryDate) {
        return ['status' => 'Active', 'class' => 'success', 'icon' => '🟢'];
    } else {
        return ['status' => 'Expired', 'class' => 'danger', 'icon' => '🔴'];
    }
}

// Function to get replacement count for a battery
function getReplacementCount($pdo, $batteryId) {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM replacement_history WHERE battery_id = ?");
    $stmt->execute([$batteryId]);
    return $stmt->fetch()['count'];
}

// Function to format replacement number
function formatReplacementNumber($num) {
    $suffix = 'th';
    if ($num == 1) $suffix = 'st';
    elseif ($num == 2) $suffix = 'nd';
    elseif ($num == 3) $suffix = 'rd';
    return $num . $suffix . ' Replacement';
}

// Function to verify admin login (supports both MD5 and password_hash)
function verifyAdminLogin($pdo, $username, $password) {
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();
    
    if ($admin) {
        // Check both password_hash and MD5
        if (password_verify($password, $admin['password']) || md5($password) == $admin['password']) {
            return $admin;
        }
    }
    return false;
}
?>