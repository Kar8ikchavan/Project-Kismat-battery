<?php
require_once '../config/database.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: ../pages/login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $battery_id = $_POST['battery_id'];
    $replacement_no = $_POST['replacement_no'];
    $customer_name = $_POST['customer_name'];
    $mobile = $_POST['mobile'];
    $battery_type = $_POST['battery_type'];
    $company = $_POST['company'];
    $ticket_no = $_POST['ticket_no'] ?? '';
    $old_model_no = $_POST['old_model_no'];
    $new_model_no = $_POST['new_model_no'];
    $old_serial_no = $_POST['old_serial_no'];
    $new_serial_no = $_POST['new_serial_no'];
    $replacement_date = $_POST['replacement_date'];
    $dispatch_date = $_POST['dispatch_date'] ?? null;
    $decision = $_POST['decision'];
    $query_status = $_POST['query_status'];
    $remarks = $_POST['remarks'] ?? '';
    
    // File Upload
    $document_file = null;
    if (isset($_FILES['document_file']) && $_FILES['document_file']['error'] == 0) {
        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $filename = $_FILES['document_file']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $filesize = $_FILES['document_file']['size'];
        
        if (in_array($ext, $allowed) && $filesize <= 1048576) {
            $new_filename = time() . '_replacement_' . preg_replace('/[^a-zA-Z0-9.]/', '_', $filename);
            $upload_path = '../assets/uploads/' . $new_filename;
            
            if (move_uploaded_file($_FILES['document_file']['tmp_name'], $upload_path)) {
                $document_file = $new_filename;
            }
        }
    }
    
    $stmt = $pdo->prepare("INSERT INTO replacement_history (battery_id, replacement_no, customer_name, mobile, battery_type, company, ticket_no, old_model_no, new_model_no, old_serial_no, new_serial_no, replacement_date, dispatch_date, decision, query_status, remarks, document_file) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $result = $stmt->execute([$battery_id, $replacement_no, $customer_name, $mobile, $battery_type, $company, $ticket_no, $old_model_no, $new_model_no, $old_serial_no, $new_serial_no, $replacement_date, $dispatch_date, $decision, $query_status, $remarks, $document_file]);
    
    if ($result) {
        $_SESSION['success'] = "Replacement recorded successfully!";
    } else {
        $_SESSION['error'] = "Failed to record replacement!";
    }
    
    header('Location: ../pages/customer_profile.php?id=' . $battery_id);
    exit();
}
?>