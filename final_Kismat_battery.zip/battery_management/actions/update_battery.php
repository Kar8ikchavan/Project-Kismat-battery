<?php
require_once '../config/database.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: ../pages/login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $customer_name = $_POST['customer_name'];
    $mobile = $_POST['mobile'];
    $battery_type = $_POST['battery_type'];
    $company = $_POST['company'];
    $model_type = $_POST['model_type'];
    $serial_number = $_POST['serial_number'];
    $ticket_no = $_POST['ticket_no'] ?? '';
    $sell_date = $_POST['sale_date'];
    $referred_by = $_POST['referred_by'] ?? '';
    
    $warranty_months = $_POST['warranty_months'];
    if ($warranty_months == 'custom') {
        $warranty_months = $_POST['custom_warranty'];
    }
    
    $warranty_expiry = $_POST['warranty_expiry'];
    
    // File Upload
    $bill_file = null;
    if (isset($_FILES['bill_file']) && $_FILES['bill_file']['error'] == 0) {
        $allowed = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
        $filename = $_FILES['bill_file']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $filesize = $_FILES['bill_file']['size'];
        
        if (in_array($ext, $allowed) && $filesize <= 1048576) {
            $new_filename = time() . '_' . preg_replace('/[^a-zA-Z0-9.]/', '_', $filename);
            $upload_path = '../assets/uploads/' . $new_filename;
            
            if (move_uploaded_file($_FILES['bill_file']['tmp_name'], $upload_path)) {
                $bill_file = $new_filename;
                
                // Delete old file if exists
                $stmt = $pdo->prepare("SELECT bill_file FROM sold_batteries WHERE id = ?");
                $stmt->execute([$id]);
                $old = $stmt->fetch();
                if ($old['bill_file'] && file_exists('../assets/uploads/' . $old['bill_file'])) {
                    unlink('../assets/uploads/' . $old['bill_file']);
                }
            }
        }
    }
    
    if ($bill_file) {
        $stmt = $pdo->prepare("UPDATE sold_batteries SET customer_name=?, mobile=?, battery_type=?, company=?, model_type=?, serial_number=?, ticket_no=?, sell_date=?, warranty_months=?, warranty_expiry_date=?, referred_by=?, bill_file=? WHERE id=?");
        $result = $stmt->execute([$customer_name, $mobile, $battery_type, $company, $model_type, $serial_number, $ticket_no, $sell_date, $warranty_months, $warranty_expiry, $referred_by, $bill_file, $id]);
    } else {
        $stmt = $pdo->prepare("UPDATE sold_batteries SET customer_name=?, mobile=?, battery_type=?, company=?, model_type=?, serial_number=?, ticket_no=?, sell_date=?, warranty_months=?, warranty_expiry_date=?, referred_by=? WHERE id=?");
        $result = $stmt->execute([$customer_name, $mobile, $battery_type, $company, $model_type, $serial_number, $ticket_no, $sell_date, $warranty_months, $warranty_expiry, $referred_by, $id]);
    }
    
    if ($result) {
        $_SESSION['success'] = "Battery record updated successfully!";
    } else {
        $_SESSION['error'] = "Failed to update record!";
    }
    
    header('Location: ../pages/sold_batteries.php');
    exit();
}
?>