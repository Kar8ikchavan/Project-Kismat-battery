<?php
require_once '../config/database.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: ../pages/login.php');
    exit();
}

$id = $_GET['id'] ?? 0;

if ($id) {
    try {
        // First delete related replacement history
        $stmt = $pdo->prepare("DELETE FROM replacement_history WHERE battery_id = ?");
        $stmt->execute([$id]);
        
        // Then delete the battery
        $stmt = $pdo->prepare("DELETE FROM sold_batteries WHERE id = ?");
        $stmt->execute([$id]);
        
        $_SESSION['success'] = "Battery record deleted successfully!";
    } catch(Exception $e) {
        $_SESSION['error'] = "Failed to delete: " . $e->getMessage();
    }
} else {
    $_SESSION['error'] = "Invalid battery ID";
}

header('Location: ../pages/sold_batteries.php');
exit();
?>