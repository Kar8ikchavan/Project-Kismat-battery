<?php
require_once '../config/database.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: ../pages/login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_name = $_POST['customer_name'];
    $mobile = $_POST['mobile'];
    $battery_type = $_POST['battery_type'];
    $company = $_POST['company'] ?? '';
    $model_type = $_POST['model_type'];
    $serial_number = $_POST['serial_number'];
    $ticket_no = $_POST['ticket_no'] ?? '';
    $sell_date = $_POST['sale_date'];
    $referred_by = $_POST['referred_by'] ?? '';
    
    // Check for duplicates before saving
    $check = $pdo->prepare("SELECT COUNT(*) FROM sold_batteries WHERE serial_number = ? OR (ticket_no IS NOT NULL AND ticket_no = ?)");
    $check->execute([$serial_number, $ticket_no]);
    $duplicateCount = $check->fetchColumn();
    
    if ($duplicateCount > 0) {
        $_SESSION['error'] = "Duplicate entry! Serial number or Ticket number already exists.";
        header('Location: ../pages/new_sale.php');
        exit();
    }
    
    $warranty_months = $_POST['warranty_months'];
    if ($warranty_months == 'custom') {
        $warranty_months = $_POST['custom_warranty'];
    }
    
    $warranty_expiry = $_POST['warranty_expiry'];
    
    // File Upload
    $bill_file = null;
    if (isset($_FILES['bill_file']) && $_FILES['bill_file']['error'] == 0) {
        $allowed = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
        $filename = $_FILES['bill_file']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $filesize = $_FILES['bill_file']['size'];
        
        if (in_array($ext, $allowed) && $filesize <= 1048576) {
            $new_filename = time() . '_' . preg_replace('/[^a-zA-Z0-9.]/', '_', $filename);
            $upload_path = '../assets/uploads/' . $new_filename;
            
            if (move_uploaded_file($_FILES['bill_file']['tmp_name'], $upload_path)) {
                $bill_file = $new_filename;
            }
        }
    }
    
    try {
        $stmt = $pdo->prepare("INSERT INTO sold_batteries (customer_name, mobile, battery_type, company, model_type, serial_number, ticket_no, sell_date, warranty_months, warranty_expiry_date, referred_by, bill_file) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        $result = $stmt->execute([$customer_name, $mobile, $battery_type, $company, $model_type, $serial_number, $ticket_no, $sell_date, $warranty_months, $warranty_expiry, $referred_by, $bill_file]);
        
        if ($result) {
            $_SESSION['success'] = "Battery sale recorded successfully!";
            header('Location: ../pages/sold_batteries.php');
        } else {
            throw new Exception("Failed to save");
        }
    } catch(PDOException $e) {
        if ($e->errorInfo[1] == 1062) { // Duplicate entry error
            $_SESSION['error'] = "Duplicate entry! Serial number or Ticket number already exists.";
        } else {
            $_SESSION['error'] = "Database error: " . $e->getMessage();
        }
        header('Location: ../pages/new_sale.php');
    }
    exit();
}
?>