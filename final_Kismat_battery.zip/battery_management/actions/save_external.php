<?php
require_once '../config/database.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: ../pages/login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_name = $_POST['customer_name'];
    $mobile = $_POST['mobile'];
    $battery_type = $_POST['battery_type'] ?? '';
    $company = $_POST['company'] ?? '';
    $model_type = $_POST['model_type'] ?? '';
    $serial_number = $_POST['serial_number'] ?? '';
    $warranty_details = $_POST['warranty_details'] ?? '';
    $problem_description = $_POST['problem_description'] ?? '';
    $replacement_notes = $_POST['replacement_notes'] ?? '';
    
    // File Upload
    $bill_file = null;
    if (isset($_FILES['bill_file']) && $_FILES['bill_file']['error'] == 0) {
        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $filename = $_FILES['bill_file']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $filesize = $_FILES['bill_file']['size'];
        
        if (in_array($ext, $allowed) && $filesize <= 1048576) {
            $new_filename = time() . '_external_' . preg_replace('/[^a-zA-Z0-9.]/', '_', $filename);
            $upload_path = '../assets/uploads/' . $new_filename;
            
            if (move_uploaded_file($_FILES['bill_file']['tmp_name'], $upload_path)) {
                $bill_file = $new_filename;
            }
        }
    }
    
    $stmt = $pdo->prepare("INSERT INTO external_replacements (customer_name, mobile, battery_type, company, model_type, serial_number, warranty_details, problem_description, replacement_notes, bill_file) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $result = $stmt->execute([$customer_name, $mobile, $battery_type, $company, $model_type, $serial_number, $warranty_details, $problem_description, $replacement_notes, $bill_file]);
    
    if ($result) {
        $_SESSION['success'] = "External replacement recorded successfully!";
    } else {
        $_SESSION['error'] = "Failed to record external replacement!";
    }
    
    header('Location: ../pages/external_replacements.php');
    exit();
}
?>