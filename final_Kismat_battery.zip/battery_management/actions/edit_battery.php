<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../pages/login.php');
    exit();
}

$id = $_GET['id'] ?? 0;
header("Location: ../pages/edit_battery.php?id=$id");
exit();
?>