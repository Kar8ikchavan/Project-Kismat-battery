<?php
// No function declarations here
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Battery Management System</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            overflow-x: hidden;
        }
        
        .wrapper {
            display: flex;
            width: 100%;
        }
        
        #sidebar {
            min-width: 260px;
            max-width: 260px;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: #fff;
            transition: all 0.3s;
            min-height: 100vh;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            
        }
        
        #sidebar.active {
            margin-left: -260px;
        }
        
        #sidebar .sidebar-header {
            background: linear-gradient(135deg, #4a6a9b 0%, #9bbdf8 100%);
            align-items: center;
            padding-left:50px;
            padding-bottom:20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        #sidebar .sidebar-header h3 {
            font-size: 1.3rem;
            margin: 0;
        }
        
        #sidebar ul.components {
            padding: 20px 0;
        }
        
        #sidebar ul li a {
            padding: 12px 20px;
            font-size: 1rem;
            display: block;
            color: #fff;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        
        #sidebar ul li a:hover {
            background: rgba(255,255,255,0.1);
            border-left-color: #ffc107;
        }
        
        #sidebar ul li.active > a {
            background: rgba(255,255,255,0.15);
            border-left-color: #ffc107;
        }
        
        #sidebar ul li a i {
            margin-right: 10px;
            width: 25px;
        }
        
        #content {
            width: 100%;
            transition: all 0.3s;
        }
        
        .navbar {
            padding: 15px 20px;
            background: white;
            border-bottom: 1px solid #ddd;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        #sidebarCollapse {
            background: #1e3c72;
            border: none;
            color: white;
        }
        
        .card-stats {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s;
            cursor: pointer;
        }
        
        .card-stats:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
        }
        
        @media (max-width: 768px) {
            #sidebar {
                margin-left: -260px;
            }
            #sidebar.active {
                margin-left: 0;
            }
            .table-responsive {
                font-size: 12px;
            }
        }
        
        .warranty-active {
            color: #28a745;
            font-weight: bold;
        }
        
        .warranty-expired {
            color: #dc3545;
            font-weight: bold;
        }
        
        .replacement-timeline {
            position: relative;
            padding-left: 30px;
        }
        
        .replacement-timeline::before {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #ddd;
        }
        
        .timeline-item {
            position: relative;
            padding: 15px;
            margin-bottom: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            border-left: 3px solid #1e3c72;
        }
        
        .timeline-item::before {
            content: '↓';
            position: absolute;
            left: -22px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
            color: #1e3c72;
        }
        
        .btn-action {
            padding: 5px 10px;
            margin: 2px;
            font-size: 12px;
        }
        
        .search-box {
            position: relative;
        }
        
        .search-results {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            max-height: 300px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .search-results .result-item {
            padding: 10px;
            cursor: pointer;
            border-bottom: 1px solid #eee;
            transition: background 0.2s;
        }
        
        .search-results .result-item:hover {
            background: #e3f2fd;
        }
        
        .loading {
            text-align: center;
            padding: 20px;
            color: #666;
        }
    </style>
</head>
<body>
<div class="wrapper">