<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div id="sidebar">
    <div class="sidebar-header">
        <img src="kismat_logo.png" width="150" alt="Kismat Battery Shop">
    </div>
    <ul class="list-unstyled components">
        <li class="<?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
            <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        </li>
        <li class="<?php echo $current_page == 'new_sale.php' ? 'active' : ''; ?>">
            <a href="new_sale.php"><i class="fas fa-plus-circle"></i> New Sale</a>
        </li>
        <li class="<?php echo $current_page == 'sold_batteries.php' ? 'active' : ''; ?>">
            <a href="sold_batteries.php"><i class="fas fa-shopping-cart"></i> Sold Batteries</a>
        </li>
        <li class="<?php echo $current_page == 'replacements.php' ? 'active' : ''; ?>">
            <a href="replacements.php"><i class="fas fa-exchange-alt"></i> Replacements</a>
        </li>
        <li class="<?php echo $current_page == 'external_replacements.php' ? 'active' : ''; ?>">
            <a href="external_replacements.php"><i class="fas fa-store"></i> External Replacements</a>
        </li>
        <li class="<?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
            <a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
        </li>
        <li class="<?php echo $current_page == 'settings.php' ? 'active' : ''; ?>">
            <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
        </li>
        <li>
            <a href="../actions/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </li>
    </ul>
</div>
<div id="content">
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <button type="button" id="sidebarCollapse" class="btn btn-info">
                <i class="fas fa-bars"></i>
            </button>
            <div class="ms-auto">
                <span class="me-3"><i class="fas fa-user-shield"></i> Welcome, Admin</span>
                <span><i class="fas fa-calendar-alt"></i> <?php echo date('d-m-Y'); ?></span>
            </div>
        </div>
    </nav>