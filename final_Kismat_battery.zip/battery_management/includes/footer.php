    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function() {
    $('#sidebarCollapse').on('click', function() {
        $('#sidebar').toggleClass('active');
    });
    
    // Initialize DataTables if exists
    if ($('.datatable').length) {
        $('.datatable').DataTable({
            responsive: true,
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ entries"
            }
        });
    }
});

// Show success/error messages
<?php if(isset($_SESSION['success'])): ?>
    Swal.fire({
        title: 'Success!',
        text: '<?php echo $_SESSION['success']; ?>',
        icon: 'success',
        timer: 3000,
        showConfirmButton: false
    });
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>

<?php if(isset($_SESSION['error'])): ?>
    Swal.fire({
        title: 'Error!',
        text: '<?php echo $_SESSION['error']; ?>',
        icon: 'error',
        timer: 3000,
        showConfirmButton: false
    });
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

// Global AJAX function for search
function searchCustomer(searchTerm, type, callback) {
    if (searchTerm.length < 2) {
        callback([]);
        return;
    }
    
    $.ajax({
        url: '../ajax/search_customer.php',
        method: 'GET',
        data: { search: searchTerm, type: type },
        dataType: 'json',
        success: function(data) {
            callback(data);
        },
        error: function() {
            callback([]);
        }
    });
}
</script>
</body>
</html>