<?php
// Authentication check for all protected pages
function checkAuth() {
    if (!isset($_SESSION['admin_id'])) {
        header('Location: ../pages/login.php');
        exit();
    }
}

// Call this at the beginning of each protected page
if (basename($_SERVER['PHP_SELF']) != 'login.php') {
    if (!isset($_SESSION['admin_id']) && !strpos($_SERVER['PHP_SELF'], 'login.php')) {
        header('Location: ../pages/login.php');
        exit();
    }
}
?>