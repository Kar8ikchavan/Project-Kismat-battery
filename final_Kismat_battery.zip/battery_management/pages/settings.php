<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach($_POST as $key => $value) {
        if ($key != 'submit') {
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
            $stmt->execute([$key, $value, $value]);
        }
    }
    $_SESSION['success'] = "Settings updated successfully!";
    header('Location: settings.php');
    exit();
}

$settings = [];
$stmt = $pdo->query("SELECT * FROM settings");
while($row = $stmt->fetch()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>

<div class="container-fluid p-4">
    <h2 class="mb-4"><i class="fas fa-cog"></i> System Settings</h2>
    
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5>General Settings</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Shop Name</label>
                            <input type="text" name="shop_name" class="form-control" value="<?php echo $settings['shop_name'] ?? 'Battery Shop'; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">GST Number</label>
                            <input type="text" name="gst_number" class="form-control" value="<?php echo $settings['gst_number'] ?? ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="text" name="phone" class="form-control" value="<?php echo $settings['phone'] ?? ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo $settings['email'] ?? ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-control" rows="3"><?php echo $settings['address'] ?? ''; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Currency Symbol</label>
                            <input type="text" name="currency" class="form-control" value="<?php echo $settings['currency'] ?? '₹'; ?>" maxlength="5">
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Settings
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5>System Information</h5>
                </div>
                <div class="card-body">
                    <table class="table">
                        <tr><th>PHP Version</th><td><?php echo phpversion(); ?></td></tr>
                        <tr><th>MySQL Version</th><td><?php echo $pdo->getAttribute(PDO::ATTR_SERVER_VERSION); ?></td></tr>
                        <tr><th>Server Software</th><td><?php echo $_SERVER['SERVER_SOFTWARE']; ?></td></tr>
                        <tr><th>Upload Max Size</th><td><?php echo ini_get('upload_max_filesize'); ?></td></tr>
                        <tr><th>Session Save Path</th><td><?php echo session_save_path(); ?></td></tr>
                    </table>
                </div>
            </div>
            
            <div class="card mt-4">
                <div class="card-header bg-warning">
                    <h5>Change Admin Password</h5>
                </div>
                <div class="card-body">
                    <form action="change_password.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" name="new_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-warning">
                            <i class="fas fa-key"></i> Change Password
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add this in the General Settings section -->
<div class="mb-3">
    <label class="form-label">SAP Code</label>
    <input type="text" name="sap_code" class="form-control" value="<?php echo $settings['sap_code'] ?? ''; ?>">
    <small class="text-muted">Your company SAP code for claim forms</small>
</div>

<?php require_once '../includes/footer.php'; ?>