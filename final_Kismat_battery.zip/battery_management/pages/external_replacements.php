<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';
requireLogin();

// Fetch existing battery type options from database
$stmt = $pdo->query("SELECT DISTINCT battery_type FROM external_replacements WHERE battery_type IS NOT NULL AND battery_type != '' AND battery_type NOT IN ('2 Wheeler', '4 Wheeler', 'Inverter') ORDER BY battery_type");
$existingBatteryTypes = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Fetch existing company options from database
$stmt = $pdo->query("SELECT DISTINCT company FROM external_replacements WHERE company IS NOT NULL AND company != '' AND company NOT IN ('Exide', 'Amaron', 'Swift', 'Powerzone') ORDER BY company");
$existingCompanies = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Default options
$defaultBatteryTypes = ['2 Wheeler', '4 Wheeler', 'Inverter'];
$defaultCompanies = ['Exide', 'Amaron', 'Swift', 'Powerzone'];

// Merge existing with defaults and remove duplicates
$batteryTypeOptions = array_unique(array_merge($defaultBatteryTypes, $existingBatteryTypes));
$companyOptions = array_unique(array_merge($defaultCompanies, $existingCompanies));

// Sort options
sort($batteryTypeOptions);
sort($companyOptions);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_external'])) {
    $customer_name = $_POST['customer_name'];
    $mobile = $_POST['mobile'];
    $battery_type = $_POST['battery_type'];
    $company = $_POST['company'];
    $model_type = $_POST['model_type'];
    $serial_number = $_POST['serial_number'];
    $warranty_details = $_POST['warranty_details'];
    $problem_description = $_POST['problem_description'];
    $replacement_notes = $_POST['replacement_notes'];
    
    // Check for duplicate serial number
    if ($serial_number) {
        $check = $pdo->prepare("SELECT COUNT(*) FROM external_replacements WHERE serial_number = ?");
        $check->execute([$serial_number]);
        if ($check->fetchColumn() > 0) {
            $_SESSION['error'] = "Serial number already exists!";
            header('Location: external_replacements.php');
            exit();
        }
    }
    
    $document_file = null;
    if (isset($_FILES['bill_file']) && $_FILES['bill_file']['error'] == 0) {
        $allowed = ['pdf', 'jpg', 'jpeg', 'png'];
        $filename = $_FILES['bill_file']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (in_array($ext, $allowed) && $_FILES['bill_file']['size'] <= 1048576) {
            $new_filename = time() . '_external_' . preg_replace('/[^a-zA-Z0-9.]/', '_', $filename);
            move_uploaded_file($_FILES['bill_file']['tmp_name'], '../assets/uploads/' . $new_filename);
            $document_file = $new_filename;
        }
    }
    
    $stmt = $pdo->prepare("INSERT INTO external_replacements (customer_name, mobile, battery_type, company, model_type, serial_number, warranty_details, problem_description, replacement_notes, bill_file) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$customer_name, $mobile, $battery_type, $company, $model_type, $serial_number, $warranty_details, $problem_description, $replacement_notes, $document_file]);
    
    $_SESSION['success'] = "External replacement recorded successfully!";
    header('Location: external_replacements.php');
    exit();
}

// Handle delete
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $pdo->prepare("DELETE FROM external_replacements WHERE id = ?");
    $stmt->execute([$delete_id]);
    $_SESSION['success'] = "Record deleted successfully!";
    header('Location: external_replacements.php');
    exit();
}

// Fetch external replacements
$externalReplacements = $pdo->query("SELECT * FROM external_replacements ORDER BY id DESC")->fetchAll();
?>

<div class="container-fluid p-4">
    <h2 class="mb-4"><i class="fas fa-store"></i> External Shop Replacements</h2>
    
    <!-- Add External Replacement Form -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5><i class="fas fa-plus"></i> Register External Replacement</h5>
        </div>
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data" id="externalForm">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Customer Name *</label>
                        <input type="text" name="customer_name" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Mobile Number *</label>
                        <input type="tel" name="mobile" class="form-control" pattern="[0-9]{10}" required>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Battery Type</label>
                        <div class="input-group">
                            <select name="battery_type" id="battery_type" class="form-select">
                                <option value="">Select</option>
                                <?php foreach($batteryTypeOptions as $option): ?>
                                    <option value="<?php echo htmlspecialchars($option); ?>"><?php echo htmlspecialchars($option); ?></option>
                                <?php endforeach; ?>
                                <option value="other">+ Add New (Other)</option>
                            </select>
                            <input type="text" name="battery_type_new" id="battery_type_new" class="form-control" placeholder="Enter new battery type" style="display: none;">
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Company</label>
                        <div class="input-group">
                            <select name="company" id="company" class="form-select">
                                <option value="">Select</option>
                                <?php foreach($companyOptions as $option): ?>
                                    <option value="<?php echo htmlspecialchars($option); ?>"><?php echo htmlspecialchars($option); ?></option>
                                <?php endforeach; ?>
                                <option value="other">+ Add New (Other)</option>
                            </select>
                            <input type="text" name="company_new" id="company_new" class="form-control" placeholder="Enter new company" style="display: none;">
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Model Number</label>
                        <input type="text" name="model_type" class="form-control">
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Serial Number</label>
                        <input type="text" name="serial_number" id="serial_number" class="form-control">
                        <small class="text-muted" id="serial_status"></small>
                    </div>
                    
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Warranty Details</label>
                        <textarea name="warranty_details" class="form-control" rows="2" placeholder="Warranty period, expiry date, etc."></textarea>
                    </div>
                    
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Problem Description</label>
                        <textarea name="problem_description" class="form-control" rows="2" placeholder="Describe the battery problem..."></textarea>
                    </div>
                    
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Replacement Notes</label>
                        <textarea name="replacement_notes" class="form-control" rows="2" placeholder="Any additional notes about replacement..."></textarea>
                    </div>
                    
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Upload Bill</label>
                        <input type="file" name="bill_file" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
                        <small class="text-muted">Max 1MB. Allowed: PDF, JPG, JPEG, PNG</small>
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" name="save_external" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Replacement
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="fas fa-undo"></i> Reset
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- External Replacements List -->
    <div class="card">
        <div class="card-header">
            <h5><i class="fas fa-list"></i> External Replacements Records</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="externalTable">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Customer Name</th>
                            <th>Mobile</th>
                            <th>Battery Type</th>
                            <th>Company</th>
                            <th>Model</th>
                            <th>Serial No</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($externalReplacements as $ext): ?>
                        <tr>
                            <td><?php echo $ext['id']; ?></td>
                            <td><?php echo htmlspecialchars($ext['customer_name']); ?></td>
                            <td><?php echo $ext['mobile']; ?></td>
                            <td><?php echo $ext['battery_type'] ?: '-'; ?></td>
                            <td><?php echo $ext['company'] ?: '-'; ?></td>
                            <td><?php echo $ext['model_type'] ?: '-'; ?></td>
                            <td><?php echo $ext['serial_number'] ?: '-'; ?></td>
                            <td><?php echo date('d-m-Y', strtotime($ext['created_at'])); ?></td>
                            <td>
                                <button class="btn btn-sm btn-info" onclick="viewDetails(<?php echo $ext['id']; ?>)">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="deleteRecord(<?php echo $ext['id']; ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- View Details Modal -->
<div class="modal fade" id="viewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title"><i class="fas fa-file-alt"></i> External Replacement Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="modalContent">
                <div class="text-center">
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="printModal()">
                    <i class="fas fa-print"></i> Print
                </button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Initialize DataTable with proper checks to avoid reinitialization
    if (!$.fn.DataTable.isDataTable('#externalTable')) {
        $('#externalTable').DataTable({
            order: [[0, 'desc']],
            pageLength: 25,
            responsive: true,
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ entries"
            }
        });
    }
    
    // Handle "Other" option for Battery Type
    $('#battery_type').on('change', function() {
        if ($(this).val() === 'other') {
            $('#battery_type_new').show().attr('required', true).focus();
            $('#battery_type').attr('name', 'battery_type_temp');
        } else {
            $('#battery_type_new').hide().removeAttr('required').val('');
            $('#battery_type').attr('name', 'battery_type');
        }
    });
    
    // Handle "Other" option for Company
    $('#company').on('change', function() {
        if ($(this).val() === 'other') {
            $('#company_new').show().attr('required', true).focus();
            $('#company').attr('name', 'company_temp');
        } else {
            $('#company_new').hide().removeAttr('required').val('');
            $('#company').attr('name', 'company');
        }
    });
    
    // Check serial number uniqueness
    $('#serial_number').on('blur', function() {
        var serial = $(this).val();
        if (serial) {
            $.ajax({
                url: '../ajax/check_external_serial.php',
                method: 'POST',
                data: { serial_number: serial },
                dataType: 'json',
                success: function(response) {
                    if (response.exists) {
                        $('#serial_status').html('<span class="text-danger">✗ Serial number already exists!</span>');
                        $('#serial_number').addClass('is-invalid');
                    } else {
                        $('#serial_status').html('<span class="text-success">✓ Serial number available</span>');
                        $('#serial_number').removeClass('is-invalid').addClass('is-valid');
                    }
                }
            });
        } else {
            $('#serial_status').html('');
        }
    });
    
    // Form submission handling
    $('#externalForm').on('submit', function(e) {
        // Handle battery type
        if ($('#battery_type').val() === 'other') {
            var newBatteryType = $('#battery_type_new').val();
            if (!newBatteryType) {
                e.preventDefault();
                Swal.fire('Error!', 'Please enter battery type', 'error');
                return false;
            } else {
                $('<input>').attr({
                    type: 'hidden',
                    name: 'battery_type',
                    value: newBatteryType
                }).appendTo('#externalForm');
            }
        }
        
        // Handle company
        if ($('#company').val() === 'other') {
            var newCompany = $('#company_new').val();
            if (!newCompany) {
                e.preventDefault();
                Swal.fire('Error!', 'Please enter company name', 'error');
                return false;
            } else {
                $('<input>').attr({
                    type: 'hidden',
                    name: 'company',
                    value: newCompany
                }).appendTo('#externalForm');
            }
        }
    });
    
    // Reset form handling
    $('#externalForm button[type="reset"]').on('click', function() {
        setTimeout(function() {
            $('#battery_type_new').hide().removeAttr('required').val('');
            $('#company_new').hide().removeAttr('required').val('');
            $('#battery_type').attr('name', 'battery_type').val('');
            $('#company').attr('name', 'company').val('');
            $('#serial_status').html('');
            $('#serial_number').removeClass('is-invalid is-valid');
        }, 100);
    });
});

function viewDetails(id) {
    $('#viewModal').modal('show');
    
    $.ajax({
        url: '../ajax/get_external_details.php',
        method: 'GET',
        data: { id: id },
        dataType: 'html',
        success: function(html) {
            $('#modalContent').html(html);
        },
        error: function() {
            $('#modalContent').html('<div class="alert alert-danger">Error loading details</div>');
        }
    });
}

function deleteRecord(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This action cannot be undone!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'external_replacements.php?delete_id=' + id;
        }
    });
}

function printModal() {
    var printContent = document.getElementById('modalContent').innerHTML;
    var originalContent = document.body.innerHTML;
    document.body.innerHTML = '<div class="container-fluid p-4">' + printContent + '</div>';
    window.print();
    document.body.innerHTML = originalContent;
    location.reload();
}
</script>

<style>
.input-group {
    flex-wrap: nowrap;
}
.input-group .form-select {
    flex: 1;
}
.input-group input {
    width: 200px;
}
.is-valid {
    border-color: #28a745 !important;
}
.is-invalid {
    border-color: #dc3545 !important;
}
.modal-lg {
    max-width: 800px;
}
.detail-row {
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}
.detail-label {
    font-weight: bold;
    color: #1e3c72;
}
</style>

<?php require_once '../includes/footer.php'; ?>