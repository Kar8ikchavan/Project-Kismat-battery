<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';
requireLogin();

$report_type = $_GET['type'] ?? 'daily';
$date = $_GET['date'] ?? date('Y-m-d');
$month = $_GET['month'] ?? date('Y-m');
$year = $_GET['year'] ?? date('Y');
$company = $_GET['company'] ?? '';

// Build query based on report type
$query = "SELECT * FROM sold_batteries WHERE 1=1";
$title = "Sales Report";

switch($report_type) {
    case 'daily':
        $query .= " AND DATE(sell_date) = '$date'";
        $title = "Daily Sales Report - " . date('d-m-Y', strtotime($date));
        break;
    case 'weekly':
        $query .= " AND YEARWEEK(sell_date) = YEARWEEK('$date')";
        $title = "Weekly Sales Report - Week of " . date('d-m-Y', strtotime($date));
        break;
    case 'monthly':
        $query .= " AND DATE_FORMAT(sell_date, '%Y-%m') = '$month'";
        $title = "Monthly Sales Report - " . date('F Y', strtotime($month . '-01'));
        break;
    case 'yearly':
        $query .= " AND YEAR(sell_date) = '$year'";
        $title = "Yearly Sales Report - $year";
        break;
    case 'company':
        if($company) {
            $query .= " AND company = '$company'";
        }
        $title = "Company Wise Report - " . ($company ?: 'All Companies');
        break;
    case 'warranty':
        $query .= " AND warranty_expiry_date < CURDATE()";
        $title = "Warranty Expired Report";
        break;
}

$query .= " ORDER BY id DESC";

// Execute query safely
$stmt = $pdo->prepare($query);
$stmt->execute();
$reports = $stmt->fetchAll();

// Get companies for filter
$companiesStmt = $pdo->query("SELECT DISTINCT company FROM sold_batteries ORDER BY company");
$companies = $companiesStmt->fetchAll();
?>

<div class="container-fluid p-4">
    <h2 class="mb-4"><i class="fas fa-chart-bar"></i> Reports & Analytics</h2>
    
    <!-- Report Filters -->
    <div class="card mb-4">
        <div class="card-header">
            <h5><i class="fas fa-filter"></i> Filter Reports</h5>
        </div>
        <div class="card-body">
            <form method="GET" class="row g-3" id="reportForm">
                <div class="col-md-3">
                    <label class="form-label">Report Type</label>
                    <select name="type" class="form-select" onchange="this.form.submit()">
                        <option value="daily" <?php echo $report_type == 'daily' ? 'selected' : ''; ?>>Daily Report</option>
                        <option value="weekly" <?php echo $report_type == 'weekly' ? 'selected' : ''; ?>>Weekly Report</option>
                        <option value="monthly" <?php echo $report_type == 'monthly' ? 'selected' : ''; ?>>Monthly Report</option>
                        <option value="yearly" <?php echo $report_type == 'yearly' ? 'selected' : ''; ?>>Yearly Report</option>
                        <option value="company" <?php echo $report_type == 'company' ? 'selected' : ''; ?>>Company Wise</option>
                        <option value="warranty" <?php echo $report_type == 'warranty' ? 'selected' : ''; ?>>Warranty Expired</option>
                    </select>
                </div>
                
                <?php if($report_type == 'daily' || $report_type == 'weekly'): ?>
                <div class="col-md-3">
                    <label class="form-label">Date</label>
                    <input type="date" name="date" class="form-control" value="<?php echo $date; ?>" onchange="this.form.submit()">
                </div>
                <?php endif; ?>
                
                <?php if($report_type == 'monthly'): ?>
                <div class="col-md-3">
                    <label class="form-label">Month</label>
                    <input type="month" name="month" class="form-control" value="<?php echo $month; ?>" onchange="this.form.submit()">
                </div>
                <?php endif; ?>
                
                <?php if($report_type == 'yearly'): ?>
                <div class="col-md-3">
                    <label class="form-label">Year</label>
                    <select name="year" class="form-select" onchange="this.form.submit()">
                        <?php for($y = 2020; $y <= date('Y'); $y++): ?>
                        <option value="<?php echo $y; ?>" <?php echo $year == $y ? 'selected' : ''; ?>><?php echo $y; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <?php endif; ?>
                
                <?php if($report_type == 'company'): ?>
                <div class="col-md-3">
                    <label class="form-label">Company</label>
                    <select name="company" class="form-select" onchange="this.form.submit()">
                        <option value="">All Companies</option>
                        <?php foreach($companies as $comp): ?>
                        <option value="<?php echo htmlspecialchars($comp['company']); ?>" <?php echo $company == $comp['company'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($comp['company']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                
                <div class="col-md-3 d-flex align-items-end">
                    <button type="button" class="btn btn-success me-2" onclick="exportToExcel()">
                        <i class="fas fa-file-excel"></i> Export Excel
                    </button>
                   
                </div>
            </form>
        </div>
    </div>
    
    <!-- Report Summary Cards -->
    <div class="row mb-4">
    
        <?php 
        $activeWarranty = 0;
        foreach($reports as $r) {
            if($r['warranty_expiry_date'] >= date('Y-m-d')) $activeWarranty++;
        }
        ?>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h6>Active Warranty</h6>
                    <h3><?php echo $activeWarranty; ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <h6>Expired Warranty</h6>
                    <h3><?php echo count($reports) - $activeWarranty; ?></h3>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Report Table -->
    <div class="card">
        <div class="card-header">
            <h5><i class="fas fa-table"></i> <?php echo $title; ?></h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="reportTable">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Customer Name</th>
                            <th>Mobile</th>
                            <th>Company</th>
                            <th>Model</th>
                            <th>Serial No</th>
                            <th>Sell Date</th>
                            <th>Warranty Expiry</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($reports as $report): 
                            $warranty = getWarrantyStatus($report['warranty_expiry_date']);
                        ?>
                        <tr>
                            <td><?php echo $report['id']; ?></div>
                            <td><?php echo htmlspecialchars($report['customer_name']); ?></div>
                            <td><?php echo $report['mobile']; ?></div>
                            <td><?php echo $report['company']; ?></div>
                            <td><?php echo $report['model_type']; ?></div>
                            <td><?php echo $report['serial_number']; ?></div>
                            <td><?php echo date('d-m-Y', strtotime($report['sell_date'])); ?></div>
                            <td><?php echo date('d-m-Y', strtotime($report['warranty_expiry_date'])); ?></div>
                            <td>
                                <span class="badge bg-<?php echo strtolower($warranty['status']) == 'active' ? 'success' : 'danger'; ?>">
                                    <?php echo $warranty['icon']; ?> <?php echo $warranty['status']; ?>
                                </span>
                            </div>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(count($reports) == 0): ?>
                        <tr>
                            <td colspan="9" class="text-center">No records found</div>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// Global variable to track DataTable instance
var reportDataTable = null;

$(document).ready(function() {
    initializeDataTable();
});

function initializeDataTable() {
    // Check if DataTable already exists and destroy it
    if ($.fn.DataTable.isDataTable('#reportTable')) {
        $('#reportTable').DataTable().destroy();
    }
    
    // Initialize new DataTable
    reportDataTable = $('#reportTable').DataTable({
        order: [[0, 'desc']],
        pageLength: 25,
        language: {
            search: "Search:",
            lengthMenu: "Show _MENU_ entries",
            info: "Showing _START_ to _END_ of _TOTAL_ entries",
            emptyTable: "No data available in table"
        },
        drawCallback: function() {
            // Optional: Add any post-draw actions here
        }
    });
}

// Reinitialize table when form submits (page reloads, so this handles it)
$(document).on('submit', '#reportForm', function() {
    // The page will reload, so no need to destroy here
});

function exportToExcel() {
    let table = document.getElementById('reportTable');
    let html = table.outerHTML;
    let url = 'data:application/vnd.ms-excel,' + encodeURIComponent(html);
    let link = document.createElement('a');
    link.href = url;
    link.download = 'report_<?php echo $report_type; ?>_<?php echo date('Y-m-d'); ?>.xls';
    link.click();
}
</script>

<?php require_once '../includes/footer.php'; ?>