<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';
requireLogin();

// Fetch existing referred by options from database
$stmt = $pdo->query("SELECT DISTINCT referred_by FROM sold_batteries WHERE referred_by IS NOT NULL AND referred_by != '' AND referred_by != 'Other' ORDER BY referred_by");
$existingReferred = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Fetch existing company options from database
$stmt = $pdo->query("SELECT DISTINCT company FROM sold_batteries WHERE company IS NOT NULL AND company != '' AND company != 'Other' ORDER BY company");
$existingCompanies = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Fetch existing battery type options from database
$stmt = $pdo->query("SELECT DISTINCT battery_type FROM sold_batteries WHERE battery_type IS NOT NULL AND battery_type != '' AND battery_type NOT IN ('2 Wheeler', '4 Wheeler', 'Inverter') ORDER BY battery_type");
$existingBatteryTypes = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Default options
$defaultReferred = ['SANIA', 'MUSKAN BATTERY', 'ROYAL BATTERY', 'S K BATTERY', 'SUHANA WASEEM', 'MAHALAXMI', 'DAJI', 'MANE', 'SADGURU', 'NKBS', 'S K SHEGAON', 'KBS', 'B P BATTERY'];
$defaultCompanies = ['Exide', 'Amaron', 'Swift', 'Powerzone'];
$defaultBatteryTypes = ['2 Wheeler', '4 Wheeler', 'Inverter'];

// Merge existing with defaults and remove duplicates
$referredOptions = array_unique(array_merge($defaultReferred, $existingReferred));
$companyOptions = array_unique(array_merge($defaultCompanies, $existingCompanies));
$batteryTypeOptions = array_unique(array_merge($defaultBatteryTypes, $existingBatteryTypes));

// Sort options
sort($referredOptions);
sort($companyOptions);
sort($batteryTypeOptions);
?>

<div class="container-fluid p-4">
    <h2 class="mb-4"><i class="fas fa-plus-circle"></i> New Battery Sale</h2>
    
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5>Customer & Battery Information</h5>
        </div>
        <div class="card-body">
            <form id="saleForm" action="../actions/save_sale.php" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Date *</label>
                        <input type="date" name="sale_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Customer Name *</label>
                        <input type="text" name="customer_name" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Mobile Number *</label>
                        <input type="tel" name="mobile" class="form-control" pattern="[0-9]{10}" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Referred By</label>
                        <div class="input-group">
                            <select name="referred_by" id="referred_by" class="form-select">
                                <option value="">Select</option>
                                <?php foreach($referredOptions as $option): ?>
                                    <option value="<?php echo htmlspecialchars($option); ?>"><?php echo htmlspecialchars($option); ?></option>
                                <?php endforeach; ?>
                                <option value="other">+ Add New (Other)</option>
                            </select>
                            <input type="text" name="referred_by_new" id="referred_by_new" class="form-control" placeholder="Enter new referred by" style="display: none;">
                        </div>
                        <small class="text-muted" id="referred_status"></small>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Battery Type *</label>
                        <div class="input-group">
                            <select name="battery_type" id="battery_type" class="form-select" required>
                                <option value="">Select</option>
                                <?php foreach($batteryTypeOptions as $option): ?>
                                    <option value="<?php echo htmlspecialchars($option); ?>"><?php echo htmlspecialchars($option); ?></option>
                                <?php endforeach; ?>
                                <option value="other">+ Add New (Other)</option>
                            </select>
                            <input type="text" name="battery_type_new" id="battery_type_new" class="form-control" placeholder="Enter new battery type" style="display: none;">
                        </div>
                        <small class="text-muted" id="battery_type_status"></small>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Company *</label>
                        <div class="input-group">
                            <select name="company" id="company" class="form-select" required>
                                <option value="">Select</option>
                                <?php foreach($companyOptions as $option): ?>
                                    <option value="<?php echo htmlspecialchars($option); ?>"><?php echo htmlspecialchars($option); ?></option>
                                <?php endforeach; ?>
                                <option value="other">+ Add New (Other)</option>
                            </select>
                            <input type="text" name="company_new" id="company_new" class="form-control" placeholder="Enter new company" style="display: none;">
                        </div>
                        <small class="text-muted" id="company_status"></small>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Model Type *</label>
                        <input type="text" name="model_type" class="form-control" id="model_type" required>
                        <small class="text-muted" id="model_status"></small>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Battery Serial Number *</label>
                        <input type="text" name="serial_number" class="form-control" id="serial_number" required>
                        <small class="text-muted" id="serial_status"></small>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Ticket Number</label>
                        <input type="text" name="ticket_no" class="form-control" id="ticket_no">
                        <small class="text-muted" id="ticket_status"></small>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Warranty Period *</label>
                        <select name="warranty_months" id="warranty_months" class="form-select" required>
                            <option value="">Select</option>
                            <option value="12">12 Months</option>
                            <option value="18">18 Months</option>
                            <option value="24">24 Months</option>
                            <option value="36">36 Months</option>
                            <option value="custom">Custom</option>
                        </select>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Custom Warranty (Months)</label>
                        <input type="number" name="custom_warranty" id="custom_warranty" class="form-control" style="display:none;">
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Warranty Expiry Date</label>
                        <input type="date" name="warranty_expiry" id="warranty_expiry" class="form-control" readonly>
                    </div>
                    
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Upload Warranty Card/Bill (Max 1MB)</label>
                        <input type="file" name="bill_file" class="form-control" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                        <small class="text-muted">Allowed: PDF, JPG, JPEG, PNG, DOC, DOCX (Max 1MB)</small>
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Sale</button>
                    <button type="reset" class="btn btn-secondary"><i class="fas fa-undo"></i> Reset</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Handle "Other" option for Referred By
    $('#referred_by').on('change', function() {
        if ($(this).val() === 'other') {
            $('#referred_by_new').show().attr('required', true).focus();
            $('#referred_by').attr('name', 'referred_by_temp');
            $('#referred_status').html('');
        } else {
            $('#referred_by_new').hide().removeAttr('required').val('');
            $('#referred_by').attr('name', 'referred_by');
        }
    });
    
    // Handle "Other" option for Battery Type
    $('#battery_type').on('change', function() {
        if ($(this).val() === 'other') {
            $('#battery_type_new').show().attr('required', true).focus();
            $('#battery_type').attr('name', 'battery_type_temp');
            $('#battery_type_status').html('');
        } else {
            $('#battery_type_new').hide().removeAttr('required').val('');
            $('#battery_type').attr('name', 'battery_type');
        }
    });
    
    // Handle "Other" option for Company
    $('#company').on('change', function() {
        if ($(this).val() === 'other') {
            $('#company_new').show().attr('required', true).focus();
            $('#company').attr('name', 'company_temp');
            $('#company_status').html('');
        } else {
            $('#company_new').hide().removeAttr('required').val('');
            $('#company').attr('name', 'company');
        }
    });
    
    // Real-time uniqueness checks
    $('#model_type').on('blur', function() {
        checkUniqueness('model_type', $(this).val(), 'model_status');
    });
    
    $('#serial_number').on('blur', function() {
        checkUniqueness('serial_number', $(this).val(), 'serial_status');
    });
    
    $('#ticket_no').on('blur', function() {
        if ($(this).val()) {
            checkUniqueness('ticket_no', $(this).val(), 'ticket_status');
        }
    });
    
    // Form submission validation
    $('#saleForm').on('submit', function(e) {
        var isValid = true;
        
        // Handle referred by
        if ($('#referred_by').val() === 'other') {
            var newReferred = $('#referred_by_new').val();
            if (!newReferred) {
                isValid = false;
                $('#referred_status').html('<span class="text-danger">✗ Please enter referred by name</span>');
            } else {
                $('<input>').attr({
                    type: 'hidden',
                    name: 'referred_by',
                    value: newReferred
                }).appendTo('#saleForm');
            }
        }
        
        // Handle battery type
        if ($('#battery_type').val() === 'other') {
            var newBatteryType = $('#battery_type_new').val();
            if (!newBatteryType) {
                isValid = false;
                $('#battery_type_status').html('<span class="text-danger">✗ Please enter battery type</span>');
            } else {
                $('<input>').attr({
                    type: 'hidden',
                    name: 'battery_type',
                    value: newBatteryType
                }).appendTo('#saleForm');
            }
        }
        
        // Handle company
        if ($('#company').val() === 'other') {
            var newCompany = $('#company_new').val();
            if (!newCompany) {
                isValid = false;
                $('#company_status').html('<span class="text-danger">✗ Please enter company name</span>');
            } else {
                $('<input>').attr({
                    type: 'hidden',
                    name: 'company',
                    value: newCompany
                }).appendTo('#saleForm');
            }
        }
        
        // Check serial number uniqueness
        var serial = $('#serial_number').val();
        if (!checkUniquenessSync('serial_number', serial)) {
            isValid = false;
            $('#serial_status').html('<span class="text-danger">✗ Serial number already exists!</span>');
        }
        
        // Check ticket number uniqueness if provided
        var ticket = $('#ticket_no').val();
        if (ticket && !checkUniquenessSync('ticket_no', ticket)) {
            isValid = false;
            $('#ticket_status').html('<span class="text-danger">✗ Ticket number already exists!</span>');
        }
        
        if (!isValid) {
            e.preventDefault();
            Swal.fire('Error!', 'Please fix the errors before saving.', 'error');
        }
    });
    
    // Reset form handling
    $('#saleForm button[type="reset"]').on('click', function() {
        setTimeout(function() {
            // Reset all "Other" fields
            $('#referred_by_new').hide().removeAttr('required').val('');
            $('#battery_type_new').hide().removeAttr('required').val('');
            $('#company_new').hide().removeAttr('required').val('');
            
            // Reset select names
            $('#referred_by').attr('name', 'referred_by').val('');
            $('#battery_type').attr('name', 'battery_type').val('');
            $('#company').attr('name', 'company').val('');
            
            // Clear status messages
            $('#model_status, #serial_status, #ticket_status, #referred_status, #battery_type_status, #company_status').html('');
            
            // Remove validation classes
            $('.is-invalid, .is-valid').removeClass('is-invalid is-valid');
        }, 100);
    });
});

function checkUniqueness(field, value, statusElement) {
    if (!value) return;
    
    $.ajax({
        url: '../ajax/check_uniqueness.php',
        method: 'POST',
        data: { field: field, value: value },
        dataType: 'json',
        success: function(response) {
            if (response.exists) {
                $('#' + statusElement).html('<span class="text-danger">✗ ' + response.message + '</span>');
                $('#' + statusElement).closest('.mb-3').find('input, select').addClass('is-invalid');
            } else {
                $('#' + statusElement).html('<span class="text-success">✓ ' + response.message + '</span>');
                $('#' + statusElement).closest('.mb-3').find('input, select').removeClass('is-invalid').addClass('is-valid');
            }
        }
    });
}

function checkUniquenessSync(field, value) {
    var result = false;
    $.ajax({
        url: '../ajax/check_uniqueness.php',
        method: 'POST',
        async: false,
        data: { field: field, value: value },
        dataType: 'json',
        success: function(response) {
            result = !response.exists;
        }
    });
    return result;
}

// Warranty calculation
document.getElementById('warranty_months').addEventListener('change', function() {
    const customWarranty = document.getElementById('custom_warranty');
    if (this.value === 'custom') {
        customWarranty.style.display = 'block';
        customWarranty.required = true;
    } else {
        customWarranty.style.display = 'none';
        customWarranty.required = false;
        calculateExpiry();
    }
});

document.getElementById('saleForm').addEventListener('change', calculateExpiry);

function calculateExpiry() {
    const sellDate = document.querySelector('[name="sale_date"]').value;
    let months = document.getElementById('warranty_months').value;
    
    if (months === 'custom') {
        months = document.getElementById('custom_warranty').value;
    }
    
    if (sellDate && months && months !== 'custom') {
        const date = new Date(sellDate);
        date.setMonth(date.getMonth() + parseInt(months));
        const expiryDate = date.toISOString().split('T')[0];
        document.getElementById('warranty_expiry').value = expiryDate;
    }
}
</script>

<style>
.input-group {
    flex-wrap: nowrap;
}
.input-group .form-select {
    flex: 1;
}
.input-group input {
    width: 200px;
}
.is-valid {
    border-color: #28a745 !important;
    background-image: none !important;
}
.is-invalid {
    border-color: #dc3545 !important;
    background-image: none !important;
}
.text-danger {
    font-size: 12px;
}
.text-success {
    font-size: 12px;
}
</style>

<?php require_once '../includes/footer.php'; ?>