<?php
require_once '../config/database.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$battery_id = $_GET['battery_id'] ?? 0;
$replacement_id = $_GET['replacement_id'] ?? 0;

// Get battery details
$stmt = $pdo->prepare("SELECT * FROM sold_batteries WHERE id = ?");
$stmt->execute([$battery_id]);
$battery = $stmt->fetch();

// Get replacement details
$stmt = $pdo->prepare("SELECT * FROM replacement_history WHERE id = ? AND battery_id = ?");
$stmt->execute([$replacement_id, $battery_id]);
$replacement = $stmt->fetch();

if (!$battery || !$replacement) {
    die("Invalid request");
}

// Get all replacements count for this battery to determine replacement number
$stmt = $pdo->prepare("SELECT COUNT(*) FROM replacement_history WHERE battery_id = ? AND replacement_no <= ?");
$stmt->execute([$battery_id, $replacement['replacement_no']]);
$currentRepNumber = $stmt->fetchColumn();

// Get shop settings
$settings = [];
$stmt = $pdo->query("SELECT * FROM settings");
while($row = $stmt->fetch()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

// Generate Claim Form Number
$claim_no = '32062';

// Generate filename for auto-download
$customer_name_clean = preg_replace('/[^a-zA-Z0-9]/', '_', $battery['customer_name']);
$replacement_text = '';
if ($currentRepNumber == 1) {
    $replacement_text = '1st_Replacement';
} elseif ($currentRepNumber == 2) {
    $replacement_text = '2nd_Replacement';
} elseif ($currentRepNumber == 3) {
    $replacement_text = '3rd_Replacement';
} else {
    $replacement_text = $currentRepNumber . 'th_Replacement';
}
$filename = $customer_name_clean . '_' . $replacement_text . '_Claim_Form_' . date('Y-m-d') . '.pdf';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dealer Claim Form - <?php echo $battery['customer_name']; ?> - <?php echo $replacement_text; ?></title>
    <style>
        * {
            margin: 0;
            padding-top: 2px;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #fff;
            padding: 5px;
            font-size: 11px;
        }
        
        .claim-form {
            max-width: 1100px;
            margin: 0 auto;
            background: white;
            border: 1px solid #000;
            padding: 8px;
            height: auto;
        }
        
        .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 5px;
            margin-bottom: 6px;
        }
        
        .header h1 {
            font-size: 25px;
            margin-bottom: 2px;
        }
        
        .header h3 {
            font-size: 18px;
            color: #555;
        }
        
        .claim-no-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 6px;
            font-size: 15px;
        }
        
        .section {
            margin-bottom: 6px;
            border: 1px solid #ccc;
            padding: 5px;
        }
        
        .section-title {
            background: #e8e8e8;
            padding: 3px 6px;
            margin: -5px -5px 5px -5px;
            font-weight: bold;
            font-size: 15px;
            border-bottom: 1px solid #ccc;
        }
        
        .row {
            display: flex;
            margin-bottom: 4px;
            flex-wrap: wrap;
            align-items: center;
        }
        
        .label {
            width: 120px;
            font-weight: bold;
            font-size: 11px;
        }
        
        .value-line {
            flex: 1;
            border-bottom: 1px solid #000;
            padding-left: 6px;
            min-height: 18px;
        }
        
        .value-line input {
            border: none;
            width: 100%;
            padding: 1px 3px;
            font-family: inherit;
            font-size: 13px;
            background: transparent;
        }
        
        .value-line input:focus {
            outline: none;
        }
        
        .two-columns {
            display: flex;
            gap: 10px;
            margin-bottom: 4px;
        }
        
        .col {
            flex: 1;
        }
        
        .checkbox-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        
        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 4px;
            font-size: 13px;
           
        }
        
        .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
            padding-top: 0px;
        }
        
        .signature-box {
            text-align: center;
            width: 220px;
        }
        
        .signature-line {
            border-top: 1px solid #000;
            margin-top: 20px;
            padding-top: 4px;
            font-size: 12px;
            
            
        }
        
        .gravity-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 4px;
            font-size: 10px;
        }
        
        .gravity-table th, .gravity-table td {
            border: 1px solid #ccc;
            padding: 3px;
            text-align: center;
        }
        
        .gravity-table th {
            background: #e8e8e8;
        }
        
        .gravity-table input {
            border: none;
            width: 100%;
            text-align: center;
            padding: 2px;
            font-size: 10px;
            background: transparent;
        }
        
        .gravity-table input:focus {
            outline: none;
        }
        
        .footer-note {
            margin-top: 6px;
            font-size: 10px;
            text-align: center;
            border-top: 1px solid #ccc;
            padding-top: 4px;
        }
        
        .print-button {
            text-align: center;
        }
        
        .print-button button {
            padding: 6px 12px;
            margin-top: 20px;
            font-size: 15px;
            margin-right: 20px;
            background: #ffffff;
            color: black;
            font-family: "Courier New", Courier, monospace;
            font-weight:bold;
            border: 1px solid black;
            border-radius: 4px;
            cursor: pointer;
            
        }
        
        .print-button button:hover {
            background: #2a5298;
        }
        
        .form-input {
            border: none;
            border-bottom: 1px solid #000;
            width: 100%;
            padding: 1px 3px;
            font-family: inherit;
            font-size: 10px;
            background: transparent;
        }
        
        .form-input:focus {
            outline: none;
        }
        
        .customer-dealer-row {
            display: flex;
            gap: 15px;
            margin-top: 6px;
        }
        
        .customer-box, .dealer-box {
            flex: 1;
            border: 1px solid #ccc;
            padding: 10px;
        }
        
        .box-title {
            font-weight: bold;
            background: #e8e8e8;
            padding: 3px;
            margin: -6px -6px 6px -6px;
            border-bottom: 1px solid #ccc;
            text-align: center;
            font-size: 15px;
        }
        
        textarea.form-input {
            border: 1px solid #000;
            min-height: 40px;
            width: 100%;
            font-size: 15px;
        }
        
        /* PRINT STYLES - Single page, solid lines */
        @media print {
            body {
                padding: 0;
                margin: 0;
                height: 100%;
            }
            .print-button {
                display: none;
            }
            .claim-form {
                border: 1px solid #000;
                padding: 10px;
                margin: 0;
                height: 100%;
            }
            .section, .customer-box, .dealer-box {
                break-inside: avoid;
                page-break-inside: avoid;
                margin-bottom: 10px;
                margin-top: 10px;
            }
            
            /* Prevent page breaks inside sections */
            .section, .customer-dealer-row, .signature-section {
                page-break-inside: avoid;
                break-inside: avoid;
                margin-top: 10px;
            }
    
            
            /* Remove background colors for printing */
            .section-title, .box-title, .gravity-table th {
                background: #f0f0f0 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            /* Hide placeholder text when printing */
            .form-input::placeholder {
                color: transparent;
            }
            
            
            
            /* Ensure everything fits on one page */
            html, body {
                height: 100%;
                margin: 0;
                padding: 0;
            }
            
            .claim-form {
                max-height: none;
                overflow: visible;
            }
        }
        
        input[type="checkbox"] {
            width: 11px;
            height: 11px;
        }
        
        .subsection {
            margin-top: 2px;
        }
        
        .subsection strong {
            font-size: 10px;
        }
        
        /* Small cell inputs for gravity table */
        .gravity-table input {
            width: 40px;
            text-align: center;
        }
        
        .gravity-table td {
            padding: 2px;
        }
        
        /* Fix for table cell widths */
        .gravity-table th:nth-child(1),
        .gravity-table th:nth-child(2),
        .gravity-table th:nth-child(3),
        .gravity-table th:nth-child(4),
        .gravity-table th:nth-child(5),
        .gravity-table th:nth-child(6) {
            width: 45px;
        }

        .logo {
            position: absolute;
            top: -30px;
            right: 10px
            
        }
        .logo_kismat {
            position: absolute;
            top: 2px;
            left: 10px
            
        }

    </style>
</head>
<body>
   
  
    <div class="claim-form" id="claimForm">
        <div class="header">
            <h1>DEALER CLAIM FORM</h1>
            <h3>Battery Warranty Claim</h3>
        </div>
               <div class="logo_kismat">
                    <img src="kismat_logo.png" width="120" alt="Company Logo">
</div>
          <div class="logo">
                    <img src="exide_company.png" width="140" alt="Company Logo">
</div>
        <div class="claim-no-row">
            <span><strong>Complaint No./Ticket No.:</strong> <?php echo $battery['ticket_no'] ?: '_______________'; ?></span>
            <span><strong>Claim Form No.:</strong> <?php echo $claim_no; ?></span>
            <span><strong>Date:</strong> <?php echo date('d-m-Y'); ?></span>
        </div>
        
        <!-- Customer and Dealer Side by Side -->
        <div class="customer-dealer-row">
            <!-- Customer Section -->
            <div class="customer-box">
                <div class="box-title">CUSTOMER DETAILS</div>
                <div class="row">
                    <div class="label" style="width: 70px;">Name:</div>
                    <div class="value-line"><?php echo htmlspecialchars($battery['customer_name']); ?></div>
                </div>
                <div class="row">
                    <div class="label" style="width: 70px;">Address:</div>
                    <div class="value-line"><input type="text" class="form-input" placeholder="Enter customer address" id="customer_address" value=""></div>
                </div>
                <div class="row">
                    <div class="label" style="width: 70px;">Tel.:</div>
                    <div class="value-line"><?php echo $battery['mobile']; ?></div>
                </div>
            </div>
            
            <!-- Dealer Section -->
            <div class="dealer-box">
                <div class="box-title">DEALER DETAILS</div>
                <div class="row">
                    <div class="label" style="width: 70px;">Name:</div>
                    <div class="value-line"><?php echo $settings['shop_name'] ?? '_______________'; ?></div>
                </div>
                <div class="row">
                    <div class="label" style="width: 70px;">Address:</div>
                    <div class="value-line"><?php echo $settings['address'] ?? '_______________'; ?></div>
                </div>
                <div class="row">
                    <div class="label" style="width: 70px;">Tel.:</div>
                    <div class="value-line" placeholder="Enter dealer phone number"><?php echo $settings['phone'] ?? '_______________'; ?></div>
                </div>
                <div class="row">
                    <div class="label" style="width: 70px;">SAP Code:</div>
                    <div class="value-line"><input type="text" class="form-input" placeholder="Enter SAP Code" id="sap_code" value="<?php echo $settings['sap_code'] ?? ''; ?>"></div>
                </div>
            </div>
        </div>
        
        <!-- (A) BATTERY / VEHICLE DETAILS -->
        <div class="section">
            <div class="section-title">(A) BATTERY / VEHICLE DETAILS</div>
            <div class="two-columns">
                <div class="col">
                    <div class="row">
                        <div class="label" style="width: 90px;">(i) Nature of Claim:</div>
                        <div class="value">
                            <label class="checkbox-item"><input type="checkbox" name="claim_type" value="TR"> TR</label>
                            <label class="checkbox-item"><input type="checkbox" name="claim_type" value="OE"> OE</label>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="row">
                        <div class="label" style="width: 120px;">(ii) Battery sale date:</div>
                        <div class="value-line"><?php echo date('d-m-Y', strtotime($battery['sell_date'])); ?></div>
                    </div>
                </div>
            </div>
            
            <div class="two-columns">
                <div class="col">
                    <div class="row">
                        <div class="label" style="width: 90px;">(iii) Battery Type:</div>
                        <div class="value-line"><?php echo $battery['battery_type']; ?></div>
                    </div>
                </div>
                <div class="col">
                    <div class="row">
                        <div class="label" style="width: 120px;">(iv) Mfg. Code / Sr. No:</div>
                        <div class="value-line"><?php echo $battery['serial_number']; ?></div>
                    </div>
                </div>
            </div>
            
            <div class="two-columns">
                <div class="col">
                    <div class="row">
                        <div class="label" style="width: 90px;">(v) Vehicle Make:</div>
                        <div class="value-line"><input type="text" class="form-input" placeholder="Enter vehicle make" id="vehicle_make" value=""></div>
                    </div>
                </div>
                <div class="col">
                    <div class="row">
                        <div class="label" style="width: 120px;">(vi) Veh. Model:</div>
                        <div class="value-line"><input type="text" class="form-input" placeholder="Enter vehicle model" id="vehicle_model" value=""></div>
                    </div>
                </div>
            </div>
            
            <div class="two-columns">
                <div class="col">
                    <div class="row">
                        <div class="label" style="width: 90px;">(vii) Veh. Regn. No.:</div>
                        <div class="value-line"><input type="text" class="form-input" placeholder="Enter registration number" id="vehicle_reg_no" value=""></div>
                    </div>
                </div>
                <div class="col">
                    <div class="row">
                        <div class="label" style="width: 120px;">(viii) Replace new Battery No.:</div>
                        <div class="value-line"><?php echo $replacement['new_serial_no']; ?></div>
                    </div>
                </div>
            </div>
            
            <div class="two-columns">
                <div class="col">
                    <div class="row">
                        <div class="label" style="width: 90px;">(ix) Repeat Claim:</div>
                        <div class="value"><input type="checkbox" name="repeat_claim"> Yes</div>
                    </div>
                </div>
                <div class="col">
                    <div class="row">
                        <div class="label" style="width: 120px;">(x) K. M.:</div>
                        <div class="value-line"><input type="text" class="form-input" placeholder="Enter kilometers" id="kilometers" value=""></div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- (B) DOCUMENTS ENCLOSED -->
        <div class="section" style="margin-top:20px;">
            <div class="section-title">(B) DOCUMENTS ENCLOSED</div>
            <div class="checkbox-group">
                <label class="checkbox-item"><input type="checkbox"> Warranty Card</label>
                <label class="checkbox-item"><input type="checkbox"> Copy of Battery Sale Bill / Invoice</label>
                <label class="checkbox-item"><input type="checkbox"> Copy of vehicle service book</label>
                <label class="checkbox-item"><input type="checkbox"> Copy of Regn. Book</label>
                <label class="checkbox-item"><input type="checkbox"> Copy of Vehicle sale bill / invoice</label>
            </div>
        </div>
        
        <!-- (C) APPARENT CONDITION OF BATTERY -->
        <div class="section" style="margin-top:15px;">
            <div class="section-title">(C) APPARENT CONDITION OF BATTERY</div>
            
            <div class="subsection">
                <strong>(a) At the time of receipt:</strong>
                <table class="gravity-table">
                    <thead>
                        <tr>
                            <th colspan="6">Specific Gravity per Cell</th>
                            <th style="width:100px">Physical Condition</th>
                        </tr>
                        <tr>
                            <th>C1</th><th>C2</th><th>C3</th><th>C4</th><th>C5</th><th>C6</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><input type="text" placeholder=""></td>
                            <td><input type="text" placeholder=""></div></td>
                            <td><input type="text" placeholder=""></div></div></td>
                            <td><input type="text" placeholder=""></div></div></div></div></td>
                            <td><input type="text" placeholder=""></div></div></div></div></div></div></td>
                            <td><input type="text" placeholder=""></div></div></div></div></div></div></div></div></td>
                            <td><input type="text" placeholder="">
                                                  </div></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="subsection" style="margin-top: 5px;">
                <strong>(b) After Changing:</strong>
                <table class="gravity-table">
                    <thead>
                        <tr>
                            <th colspan="6">Specific Gravity per Cell</th>
                            <th style="width:50px">OCV</th>
                            <th style="width:80px">Observation</th>
                        </tr>
                        <tr>
                            <th>C1</th><th>C2</th><th>C3</th><th>C4</th><th>C5</th><th>C6</th>
                            <th></th><th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><input type="text" placeholder=""></div></td>
                            <td><input type="text" placeholder=""></div></div></div></td>
                            <td><input type="text" placeholder=""></div></div></div></div></div></div></div></div></td>
                            <td><input type="text" placeholder=""></div></div></div></div></div></div></div></div></div></td>
                            <td><input type="text" placeholder=""></div></div></div></div></div></div></div></div></div></div></div></td>
                            <td><input type="text" placeholder=""></div></div></div></div></div></div></div></div></div></div></div></div></div></div></td>
                            <td><input type="text" style="width:40px;text-align:center" placeholder=""></div></td>
                            <td><input type="text" placeholder="">                                </div></div></div></div></div></div></div></div> </div>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="two-columns" style="margin-top: 5px;">
                <div class="col">
                    <div class="row">
                        <div class="label" style="width: 130px;">Service Battery Type (if issued):</div>
                        <div class="value-line"><input type="text" class="form-input" placeholder="Service battery type" id="service_battery_type"></div>
                    </div>
                </div>
                <div class="col">
                    <div class="row">
                        <div class="label" style="width: 70px;">Mfg. Code:</div>
                        <div class="value-line"><input type="text" class="form-input" placeholder="Mfg. Code" id="mfg_code"></div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="label" style="width: 70px;">Sr. No.:</div>
                <div class="value-line" style="max-width: 280px;"><input type="text" class="form-input" placeholder="Serial number" id="service_serial_no"></div>
            </div>
        </div>
        
       
        
        <!-- Signature Section -->
        <div class="signature-section">
            <div class="signature-box">
                <div class="signature-line"></div>
                <div>(Customer's Signature)</div>
            </div>
            <div class="signature-box">
                <div class="signature-line"></div>
                <div>(Dealer's Signature)</div>
            </div>
        </div>
        
        <!-- Footer Note -->
        <div class="footer-note">
            <p>Claim Battery received. However claim acceptance is subject to further scrutiny and analysis. We are not responsible <p>if the battery is not collected within 30 days.
            Service battery must be returned within ______ days</p>
            <p>Customer's Copy / Company Copy / Dealer's Copy</p>
        </div>
    </div>    
     <div class="print-button">
        <button onclick="saveAndPrint()"> Print Claim Form</button>
        <button onclick="saveAsPDF()">Save as PDF</button>
    </div>        
    
    <script>
        // Save form data to localStorage for persistence
        function saveFormData() {
            var formData = {
                customer_address: document.getElementById('customer_address')?.value || '',
                sap_code: document.getElementById('sap_code')?.value || '',
                vehicle_make: document.getElementById('vehicle_make')?.value || '',
                vehicle_model: document.getElementById('vehicle_model')?.value || '',
                vehicle_reg_no: document.getElementById('vehicle_reg_no')?.value || '',
                kilometers: document.getElementById('kilometers')?.value || '',
                service_battery_type: document.getElementById('service_battery_type')?.value || '',
                mfg_code: document.getElementById('mfg_code')?.value || '',
                service_serial_no: document.getElementById('service_serial_no')?.value || ''
            };
            localStorage.setItem('claim_form_<?php echo $replacement_id; ?>', JSON.stringify(formData));
            return formData;
        }
        
        // Load saved form data
        function loadFormData() {
            var savedData = localStorage.getItem('claim_form_<?php echo $replacement_id; ?>');
            if (savedData) {
                var formData = JSON.parse(savedData);
                if (formData.customer_address && document.getElementById('customer_address')) 
                    document.getElementById('customer_address').value = formData.customer_address;
                if (formData.sap_code && document.getElementById('sap_code')) 
                    document.getElementById('sap_code').value = formData.sap_code;
                if (formData.vehicle_make && document.getElementById('vehicle_make')) 
                    document.getElementById('vehicle_make').value = formData.vehicle_make;
                if (formData.vehicle_model && document.getElementById('vehicle_model')) 
                    document.getElementById('vehicle_model').value = formData.vehicle_model;
                if (formData.vehicle_reg_no && document.getElementById('vehicle_reg_no')) 
                    document.getElementById('vehicle_reg_no').value = formData.vehicle_reg_no;
                if (formData.kilometers && document.getElementById('kilometers')) 
                    document.getElementById('kilometers').value = formData.kilometers;
                if (formData.service_battery_type && document.getElementById('service_battery_type')) 
                    document.getElementById('service_battery_type').value = formData.service_battery_type;
                if (formData.mfg_code && document.getElementById('mfg_code')) 
                    document.getElementById('mfg_code').value = formData.mfg_code;
                if (formData.service_serial_no && document.getElementById('service_serial_no')) 
                    document.getElementById('service_serial_no').value = formData.service_serial_no;
            }
        }
        
        // Save and Print
        function saveAndPrint() {
            saveFormData();
            window.print();
        }
        
        // Save as PDF with automatic filename
        function saveAsPDF() {
            saveFormData();
            
            // Show print dialog with filename hint
            var filename = "<?php echo $filename; ?>";
            window.print();
            
            // Note: The actual PDF saving with custom filename requires browser's print to PDF feature
            // User will need to enter the filename manually in the print dialog
            setTimeout(function() {
                alert("When the print dialog opens:\n1. Select 'Save as PDF'\n2. Enter filename: " + filename + "\n3. Click Save");
            }, 500);
        }
        
        // Auto-save on input change
        var inputs = document.querySelectorAll('.form-input, .gravity-table input');
        inputs.forEach(function(input) {
            input.addEventListener('change', saveFormData);
            input.addEventListener('keyup', saveFormData);
        });
        
        // Load saved data on page load
        loadFormData();
        
        // Ensure print dialog opens with proper settings
        window.onbeforeprint = function() {
            // Any pre-print cleanup if needed
        };
    </script>
</body>
</html>