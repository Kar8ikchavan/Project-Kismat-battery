<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';
requireLogin();

$search = $_GET['search'] ?? '';
$query = "SELECT * FROM sold_batteries";
if ($search) {
    $query .= " WHERE customer_name LIKE '%$search%' OR mobile LIKE '%$search%' OR serial_number LIKE '%$search%'";
}
$query .= " ORDER BY id DESC";
$batteries = $pdo->query($query)->fetchAll();
?>

<div class="container-fluid p-4">
    <h2 class="mb-4"><i class="fas fa-shopping-cart"></i> Sold Batteries</h2>
    
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-md-6">
                    <h5>All Sold Batteries</h5>
                </div>
                <div class="col-md-6">
                    <input type="text" id="searchInput" class="form-control" placeholder="Search by name, mobile or serial...">
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="batteriesTable">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Customer Name</th>
                            <th>Mobile</th>
                            <th>Battery Type</th>
                            <th>Company</th>
                            <th>Model</th>
                            <th>Serial No</th>
                            <th>Sell Date</th>
                            <th>Expiry Date</th>
                            <th>Warranty Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($batteries as $battery): 
                            $warranty = getWarrantyStatus($battery['warranty_expiry_date']);
                            $replacementCount = getReplacementCount($pdo, $battery['id']);
                        ?>
                            <tr>
                                <td><?php echo $battery['id']; ?></td>
                                <td style="font-weight:bold;">
                                    
                                        <?php echo htmlspecialchars($battery['customer_name']); ?>
                                    
                                </td>
                                <td><?php echo $battery['mobile']; ?></td>
                                <td><?php echo $battery['battery_type']; ?></td>
                                <td><?php echo $battery['company']; ?></td>
                                <td><?php echo $battery['model_type']; ?></td>
                                <td><?php echo $battery['serial_number']; ?></td>
                                <td><?php echo date('d-m-Y', strtotime($battery['sell_date'])); ?></td>
                                <td><?php echo date('d-m-Y', strtotime($battery['warranty_expiry_date'])); ?></td>
                                <td>
                                    <span class="warranty-<?php echo strtolower($warranty['status']); ?>">
                                        <?php echo $warranty['icon']; ?> <?php echo $warranty['status']; ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-info btn-action" onclick="viewBattery(<?php echo $battery['id']; ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-warning btn-action" onclick="editBattery(<?php echo $battery['id']; ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger btn-action" onclick="deleteBattery(<?php echo $battery['id']; ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    <button class="btn btn-sm btn-success btn-action" onclick="startReplacement(<?php echo $battery['id']; ?>)">
                                        <i class="fas fa-exchange-alt"></i> Replacement
                                    </button>
                                    <span class="badge bg-secondary"><?php echo $replacementCount; ?> Replacements</span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#searchInput').on('keyup', function() {
        var value = $(this).val().toLowerCase();
        $('#batteriesTable tbody tr').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
    });
});

function viewBattery(id) {
    window.location.href = 'customer_profile.php?id=' + id;
}

function editBattery(id) {
    window.location.href = 'edit_battery.php?id=' + id;
}

function deleteBattery(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This action cannot be undone!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '../actions/delete_battery.php?id=' + id;
        }
    });
}

function startReplacement(id) {
    Swal.fire({
        title: 'Select Replacement Type',
        text: 'Was this battery purchased from our shop?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, from my shop',
        cancelButtonText: 'No, from another shop'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'replacements.php?battery_id=' + id;
        } else if (result.dismiss === Swal.DismissReason.cancel) {
            window.location.href = 'external_replacements.php?battery_id=' + id;
        }
    });
}
</script>

<?php require_once '../includes/footer.php'; ?>