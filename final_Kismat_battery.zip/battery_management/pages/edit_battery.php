<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';
requireLogin();

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM sold_batteries WHERE id = ?");
$stmt->execute([$id]);
$battery = $stmt->fetch();

if (!$battery) {
    header('Location: sold_batteries.php');
    exit();
}

$referredOptions = ['SANIA', 'MUSKAN BATTERY', 'ROYAL BATTERY', 'S K BATTERY', 'SUHANA WASEEM', 'MAHALAXMI', 'DAJI', 'MANE', 'SADGURU', 'NKBS', 'S K SHEGAON', 'KBS', 'B P BATTERY', 'Other'];
?>

<div class="container-fluid p-4">
    <h2 class="mb-4"><i class="fas fa-edit"></i> Edit Battery Sale</h2>
    
    <div class="card">
        <div class="card-header bg-warning">
            <h5>Edit Customer & Battery Information</h5>
        </div>
        <div class="card-body">
            <form id="editForm" action="../actions/update_battery.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $battery['id']; ?>">
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Date *</label>
                        <input type="date" name="sale_date" class="form-control" value="<?php echo $battery['sell_date']; ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Customer Name *</label>
                        <input type="text" name="customer_name" class="form-control" value="<?php echo htmlspecialchars($battery['customer_name']); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Mobile Number *</label>
                        <input type="tel" name="mobile" class="form-control" value="<?php echo $battery['mobile']; ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Referred By</label>
                        <select name="referred_by" class="form-select">
                            <option value="">Select</option>
                            <?php foreach($referredOptions as $option): ?>
                                <option value="<?php echo $option; ?>" <?php echo $battery['referred_by'] == $option ? 'selected' : ''; ?>>
                                    <?php echo $option; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Battery Type *</label>
                        <select name="battery_type" class="form-select" required>
                            <option value="2 Wheeler" <?php echo $battery['battery_type'] == '2 Wheeler' ? 'selected' : ''; ?>>2 Wheeler</option>
                            <option value="4 Wheeler" <?php echo $battery['battery_type'] == '4 Wheeler' ? 'selected' : ''; ?>>4 Wheeler</option>
                            <option value="Inverter" <?php echo $battery['battery_type'] == 'Inverter' ? 'selected' : ''; ?>>Inverter</option>
                            <option value="Other" <?php echo $battery['battery_type'] == 'Other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Company *</label>
                        <select name="company" class="form-select" required>
                            <option value="Exide" <?php echo $battery['company'] == 'Exide' ? 'selected' : ''; ?>>Exide</option>
                            <option value="Amaron" <?php echo $battery['company'] == 'Amaron' ? 'selected' : ''; ?>>Amaron</option>
                            <option value="Swift" <?php echo $battery['company'] == 'Swift' ? 'selected' : ''; ?>>Swift</option>
                            <option value="Powerzone" <?php echo $battery['company'] == 'Powerzone' ? 'selected' : ''; ?>>Powerzone</option>
                            <option value="Other" <?php echo $battery['company'] == 'Other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Model Type *</label>
                        <input type="text" name="model_type" class="form-control" value="<?php echo htmlspecialchars($battery['model_type']); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Battery Serial Number *</label>
                        <input type="text" name="serial_number" class="form-control" value="<?php echo $battery['serial_number']; ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Ticket Number</label>
                        <input type="text" name="ticket_no" class="form-control" value="<?php echo $battery['ticket_no']; ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Warranty Period *</label>
                        <select name="warranty_months" id="warranty_months" class="form-select" required>
                            <option value="12" <?php echo $battery['warranty_months'] == 12 ? 'selected' : ''; ?>>12 Months</option>
                            <option value="18" <?php echo $battery['warranty_months'] == 18 ? 'selected' : ''; ?>>18 Months</option>
                            <option value="24" <?php echo $battery['warranty_months'] == 24 ? 'selected' : ''; ?>>24 Months</option>
                            <option value="36" <?php echo $battery['warranty_months'] == 36 ? 'selected' : ''; ?>>36 Months</option>
                            <option value="custom">Custom</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Custom Warranty (Months)</label>
                        <input type="number" name="custom_warranty" id="custom_warranty" class="form-control" value="<?php echo !in_array($battery['warranty_months'], [12,18,24,36]) ? $battery['warranty_months'] : ''; ?>" style="display: none;">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Warranty Expiry Date</label>
                        <input type="date" name="warranty_expiry" id="warranty_expiry" class="form-control" value="<?php echo $battery['warranty_expiry_date']; ?>" readonly>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Current Bill/Warranty Card</label>
                        <?php if($battery['bill_file']): ?>
                            <div class="mb-2">
                                <a href="../assets/uploads/<?php echo $battery['bill_file']; ?>" target="_blank" class="btn btn-sm btn-info">
                                    <i class="fas fa-file"></i> View Current File
                                </a>
                            </div>
                        <?php endif; ?>
                        <label class="form-label">Upload New File (Optional)</label>
                        <input type="file" name="bill_file" class="form-control" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                        <small class="text-muted">Leave empty to keep current file. Max 1MB</small>
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Sale</button>
                    <a href="sold_batteries.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('warranty_months').addEventListener('change', function() {
    const customWarranty = document.getElementById('custom_warranty');
    if (this.value === 'custom') {
        customWarranty.style.display = 'block';
        customWarranty.required = true;
    } else {
        customWarranty.style.display = 'none';
        customWarranty.required = false;
        calculateExpiry();
    }
});

document.getElementById('editForm').addEventListener('change', calculateExpiry);

function calculateExpiry() {
    const sellDate = document.querySelector('[name="sale_date"]').value;
    let months = document.getElementById('warranty_months').value;
    
    if (months === 'custom') {
        months = document.getElementById('custom_warranty').value;
    }
    
    if (sellDate && months && months !== 'custom') {
        const date = new Date(sellDate);
        date.setMonth(date.getMonth() + parseInt(months));
        const expiryDate = date.toISOString().split('T')[0];
        document.getElementById('warranty_expiry').value = expiryDate;
    }
}
</script>

<?php require_once '../includes/footer.php'; ?>