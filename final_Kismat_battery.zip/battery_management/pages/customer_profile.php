<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$battery_id = $_GET['id'] ?? 0;

if (!$battery_id) {
    header('Location: sold_batteries.php');
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM sold_batteries WHERE id = ?");
$stmt->execute([$battery_id]);
$battery = $stmt->fetch();

if (!$battery) {
    header('Location: sold_batteries.php');
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM replacement_history WHERE battery_id = ? ORDER BY replacement_no ASC");
$stmt->execute([$battery_id]);
$replacements = $stmt->fetchAll();

$warranty = getWarrantyStatus($battery['warranty_expiry_date']);
$replacementCount = count($replacements);
?>

<div class="container-fluid p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-user-circle"></i> Customer Profile</h2>
        <div>
            <button onclick="window.print()" class="btn btn-secondary">
                <i class="fas fa-print"></i> Print Profile
            </button>
            <a href="sold_batteries.php" class="btn btn-primary">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>
    </div>
    
    <!-- Customer Information -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5><i class="fas fa-user"></i> Customer Information</h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr><th width="150">Customer Name:</th><td><?php echo htmlspecialchars($battery['customer_name']); ?></td></tr>
                        <tr><th>Mobile Number:</th><td><?php echo $battery['mobile']; ?></td></tr>
                        <tr><th>Referred By:</th><td><?php echo $battery['referred_by'] ?: 'N/A'; ?></td></tr>
                        <tr><th>Total Replacements:</th><td><span class="badge bg-info"><?php echo $replacementCount; ?></span></td></tr>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5><i class="fas fa-car-battery"></i> Battery Information</h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr><th width="150">Battery Type:</th><td><?php echo $battery['battery_type']; ?></td></tr>
                        <tr><th>Company:</th><td><?php echo $battery['company']; ?></td></tr>
                        <tr><th>Model Type:</th><td><?php echo $battery['model_type']; ?></td></tr>
                        <tr><th>Serial Number:</th><td><strong><?php echo $battery['serial_number']; ?></strong></td></tr>
                        <tr><th>Sell Date:</th><td><?php echo date('d-m-Y', strtotime($battery['sell_date'])); ?></td></tr>
                        <tr><th>Warranty Expiry:</th><td><?php echo date('d-m-Y', strtotime($battery['warranty_expiry_date'])); ?></td></tr>
                        <tr><th>Warranty Status:</th><td><span class="warranty-<?php echo strtolower($warranty['status']); ?>"><?php echo $warranty['icon']; ?> <?php echo $warranty['status']; ?></span></td></tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Replacement Timeline with Print Buttons -->
    <div class="card">
        <div class="card-header bg-warning">
            <h5><i class="fas fa-history"></i> Complete Battery Journey Timeline</h5>
        </div>
        <div class="card-body">
            <div class="replacement-timeline">
                <!-- Original Battery -->
                <div class="timeline-item">
                    <div class="row">
                        <div class="col-md-3"><strong>Original Purchase</strong></div>
                        <div class="col-md-3">Model: <?php echo $battery['model_type']; ?></div>
                        <div class="col-md-3">Serial: <?php echo $battery['serial_number']; ?></div>
                        <div class="col-md-3">Date: <?php echo date('d-m-Y', strtotime($battery['sell_date'])); ?></div>
                    </div>
                </div>
                
                <?php foreach($replacements as $index => $rep): ?>
                <div class="timeline-item">
                    <div class="row">
                        <div class="col-md-3"><strong><?php echo formatReplacementNumber($rep['replacement_no']); ?></strong></div>
                        <div class="col-md-3">New Model: <?php echo $rep['new_model_no']; ?></div>
                        <div class="col-md-3">New Serial: <?php echo $rep['new_serial_no']; ?></div>
                        <div class="col-md-3">Date: <?php echo date('d-m-Y', strtotime($rep['replacement_date'])); ?></div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-4">Decision: <?php echo $rep['decision']; ?></div>
                        <div class="col-md-4">Status: <?php echo $rep['query_status']; ?></div>
                        <div class="col-md-4">
                            <?php if($rep['document_file']): ?>
                                <a href="../assets/uploads/<?php echo $rep['document_file']; ?>" target="_blank" class="btn btn-sm btn-info">
                                    <i class="fas fa-file"></i> View Document
                                </a>
                            <?php endif; ?>
                            <button onclick="printClaimForm(<?php echo $battery['id']; ?>, <?php echo $rep['id']; ?>)" class="btn btn-sm btn-success">
                                <i class="fas fa-print"></i> Print Claim Form
                            </button>
                        </div>
                    </div>
                    <?php if($rep['remarks']): ?>
                    <div class="row mt-2">
                        <div class="col-12"><small><strong>Remarks:</strong> <?php echo $rep['remarks']; ?></small></div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <div class="mt-4 text-center">
        <a href="replacements.php?battery_id=<?php echo $battery['id']; ?>" class="btn btn-success btn-lg">
            <i class="fas fa-exchange-alt"></i> New Replacement
        </a>
    </div>
</div>

<script>
function printClaimForm(batteryId, replacementId) {
    window.open('print_claim_form.php?battery_id=' + batteryId + '&replacement_id=' + replacementId, '_blank', 'width=900,height=700');
}
</script>

<style>
@media print {
    #sidebar, .navbar, .btn, .btn-lg, .card-header .btn {
        display: none !important;
    }
    #content {
        margin-left: 0 !important;
        width: 100% !important;
    }
    .card {
        break-inside: avoid;
        border: 1px solid #ddd;
    }
}

.timeline-item {
    position: relative;
    padding: 15px;
    margin-bottom: 15px;
    background: #f8f9fa;
    border-radius: 8px;
    border-left: 3px solid #1e3c72;
}

.replacement-timeline {
    position: relative;
    padding-left: 20px;
}

.replacement-timeline::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #ddd;
}

.timeline-item::before {
    content: '▼';
    position: absolute;
    left: -12px;
    top: 20px;
    font-size: 14px;
    color: #1e3c72;
}
</style>

<?php require_once '../includes/footer.php'; ?>