<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';
requireLogin();

$battery_id = $_GET['battery_id'] ?? 0;
$battery = null;
$replacements = [];
$replacementCount = 0;

// Fetch recent batteries for quick access
$recentBatteries = $pdo->query("SELECT id, customer_name, mobile, serial_number, company, model_type, warranty_expiry_date, created_at FROM sold_batteries ORDER BY id DESC LIMIT 10")->fetchAll();

if ($battery_id) {
    $stmt = $pdo->prepare("SELECT * FROM sold_batteries WHERE id = ?");
    $stmt->execute([$battery_id]);
    $battery = $stmt->fetch();
    
    if ($battery) {
        $stmt = $pdo->prepare("SELECT * FROM replacement_history WHERE battery_id = ? ORDER BY replacement_no ASC");
        $stmt->execute([$battery_id]);
        $replacements = $stmt->fetchAll();
        $replacementCount = count($replacements);
    }
}
?>

<div class="container-fluid p-4">
    <h2 class="mb-4"><i class="fas fa-exchange-alt"></i> Battery Replacement Management</h2>
    
    <?php if (!$battery_id): ?>
    <!-- Search Section -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5><i class="fas fa-search"></i> Search Customer for Replacement</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Search by Mobile Number</label>
                    <div class="search-box">
                        <input type="text" id="mobileSearch" class="form-control" placeholder="Enter mobile number...">
                        <div id="mobileResults" class="search-results"></div>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Search by Name / Serial / Ticket</label>
                    <div class="search-box">
                        <input type="text" id="generalSearch" class="form-control" placeholder="Search by name, serial number or ticket...">
                        <div id="generalResults" class="search-results"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Batteries Section -->
    <div class="card">
        <div class="card-header bg-secondary text-white">
            <h5><i class="fas fa-history"></i> Recent Records</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="recentTable">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Customer Name</th>
                            <th>Mobile</th>
                            <th>Company</th>
                            <th>Model</th>
                            <th>Serial No</th>
                            <th>Warranty Status</th>
                            <th>Replacement Count</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($recentBatteries as $recent): 
                            $warranty = getWarrantyStatus($recent['warranty_expiry_date']);
                            $repCount = getReplacementCount($pdo, $recent['id']);
                        ?>
                        <tr>
                            <td><?php echo $recent['id']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($recent['customer_name']); ?></strong>
                                <br>
                                <small class="text-muted"><?php echo $recent['created_at'] ? date('d-m-Y', strtotime($recent['created_at'])) : ''; ?></small>
                             </div>
                            </td>
                            <td><?php echo $recent['mobile']; ?></td>
                            <td><?php echo $recent['company']; ?></td>
                            <td><?php echo $recent['model_type']; ?></td>
                            <td><code><?php echo $recent['serial_number']; ?></code></td>
                            <td>
                                <span class="badge bg-<?php echo $warranty['status'] == 'Active' ? 'success' : 'danger'; ?>">
                                    <?php echo $warranty['icon']; ?> <?php echo $warranty['status']; ?>
                                </span>
                                <br>
                                <small>Expiry: <?php echo date('d-m-Y', strtotime($recent['warranty_expiry_date'])); ?></small>
                            </td>
                            <td>
                                <span class="badge bg-info"><?php echo $repCount; ?> Replacements</span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-success" onclick="selectCustomer(<?php echo $recent['id']; ?>)">
                                    <i class="fas fa-exchange-alt"></i> Replace
                                </button>
                                <a href="customer_profile.php?id=<?php echo $recent['id']; ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-user"></i> Profile
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(count($recentBatteries) == 0): ?>
                        <tr>
                            <td colspan="9" class="text-center">No records found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <?php if ($battery): ?>
    <!-- Selected Battery Details -->
    <div class="card mb-4">
        <div class="card-header bg-info text-white">
            <h5><i class="fas fa-check-circle"></i> Selected Battery Details</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3">
                    <strong>Customer:</strong> <?php echo htmlspecialchars($battery['customer_name']); ?>
                </div>
                <div class="col-md-3">
                    <strong>Mobile:</strong> <?php echo $battery['mobile']; ?>
                </div>
                <div class="col-md-3">
                    <strong>Battery:</strong> <?php echo $battery['company'] . ' ' . $battery['model_type']; ?>
                </div>
                <div class="col-md-3">
                    <strong>Serial No:</strong> <?php echo $battery['serial_number']; ?>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-3">
                    <strong>Sell Date:</strong> <?php echo date('d-m-Y', strtotime($battery['sell_date'])); ?>
                </div>
                <div class="col-md-3">
                    <strong>Warranty Expiry:</strong> <?php echo date('d-m-Y', strtotime($battery['warranty_expiry_date'])); ?>
                </div>
                <div class="col-md-3">
                    <strong>Warranty Status:</strong> 
                    <?php 
                        $warranty = getWarrantyStatus($battery['warranty_expiry_date']);
                        echo '<span class="badge bg-' . ($warranty['status'] == 'Active' ? 'success' : 'danger') . '">' . $warranty['icon'] . ' ' . $warranty['status'] . '</span>';
                    ?>
                </div>
                <div class="col-md-3">
                    <a href="customer_profile.php?id=<?php echo $battery['id']; ?>" class="btn btn-sm btn-info">
                        <i class="fas fa-user"></i> View Full Profile
                    </a>
                    <a href="replacements.php" class="btn btn-sm btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Search
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Replacement History Timeline -->
    <div class="card mb-4">
        <div class="card-header bg-warning">
            <h5><i class="fas fa-history"></i> Replacement History Timeline (<?php echo $replacementCount; ?> replacements)</h5>
        </div>
        <div class="card-body">
            <div class="replacement-timeline">
                <!-- Original Battery -->
                <div class="timeline-item original">
                    <div class="row">
                        <div class="col-md-3"><strong>📦 Original Battery</strong></div>
                        <div class="col-md-3">Model: <?php echo $battery['model_type']; ?></div>
                        <div class="col-md-3">Serial: <?php echo $battery['serial_number']; ?></div>
                        <div class="col-md-3">Date: <?php echo date('d-m-Y', strtotime($battery['sell_date'])); ?></div>
                    </div>
                </div>
                
                <?php if(count($replacements) > 0): ?>
                    <?php foreach($replacements as $rep): ?>
                    <div class="timeline-item replacement">
                        <div class="row">
                            <div class="col-md-3"><strong>🔄 <?php echo formatReplacementNumber($rep['replacement_no']); ?></strong></div>
                            <div class="col-md-3">New Model: <?php echo $rep['new_model_no']; ?></div>
                            <div class="col-md-3">New Serial: <?php echo $rep['new_serial_no']; ?></div>
                            <div class="col-md-3">Date: <?php echo date('d-m-Y', strtotime($rep['replacement_date'])); ?></div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-4">
                                <strong>Decision:</strong> 
                                <span class="badge bg-<?php 
                                    echo $rep['decision'] == 'Pending' ? 'warning' : 
                                        ($rep['decision'] == 'Solved' ? 'success' : 'info'); 
                                ?>"><?php echo $rep['decision']; ?></span>
                            </div>
                            <div class="col-md-4">
                                <strong>Status:</strong> 
                                <span class="badge bg-<?php 
                                    echo $rep['query_status'] == 'Pending' ? 'warning' : 
                                        ($rep['query_status'] == 'Solved' ? 'success' : 'danger'); 
                                ?>"><?php echo $rep['query_status']; ?></span>
                            </div>
                            <?php if($rep['document_file']): ?>
                            <div class="col-md-4">
                                <a href="../assets/uploads/<?php echo $rep['document_file']; ?>" target="_blank" class="btn btn-sm btn-info">
                                    <i class="fas fa-file"></i> View Document
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php if($rep['remarks']): ?>
                        <div class="row mt-2">
                            <div class="col-12">
                                <small><strong>Remarks:</strong> <?php echo nl2br(htmlspecialchars($rep['remarks'])); ?></small>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="alert alert-info">No replacement history found for this battery.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- New Replacement Form -->
    <div class="card">
        <div class="card-header bg-success text-white">
            <h5><i class="fas fa-plus-circle"></i> New Replacement - <?php echo $replacementCount == 0 ? 'First Replacement' : ($replacementCount + 1) . 'th Replacement'; ?></h5>
        </div>
        <div class="card-body">
            <form id="replacementForm" action="../actions/save_replacement.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="battery_id" value="<?php echo $battery['id']; ?>">
                <input type="hidden" name="replacement_no" value="<?php echo $replacementCount + 1; ?>">
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Replacement Date *</label>
                        <input type="date" name="replacement_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Customer Name</label>
                        <input type="text" name="customer_name" class="form-control" value="<?php echo htmlspecialchars($battery['customer_name']); ?>" readonly>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Mobile Number</label>
                        <input type="text" name="mobile" class="form-control" value="<?php echo $battery['mobile']; ?>" readonly>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Battery Type</label>
                        <input type="text" name="battery_type" class="form-control" value="<?php echo $battery['battery_type']; ?>" readonly>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Company</label>
                        <input type="text" name="company" class="form-control" value="<?php echo $battery['company']; ?>" readonly>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Ticket Number</label>
                        <input type="text" name="ticket_no" class="form-control" placeholder="Enter ticket number if any">
                    </div>
                    
                    <!-- Replacement Chain Display -->
                    <div class="col-12 mb-3">
                        <div class="alert alert-info">
                            <h6><i class="fas fa-link"></i> Replacement Chain:</h6>
                            <div class="chain-display">
                                <div class="chain-item original-chain">
                                    <span class="badge bg-secondary">Original</span>
                                    Model: <?php echo $battery['model_type']; ?> | 
                                    Serial: <?php echo $battery['serial_number']; ?>
                                </div>
                                <?php foreach($replacements as $rep): ?>
                                <div class="chain-item">
                                    <i class="fas fa-arrow-down text-success"></i>
                                    <div class="chain-box">
                                        <span class="badge bg-info"><?php echo formatReplacementNumber($rep['replacement_no']); ?></span>
                                        Model: <?php echo $rep['new_model_no']; ?> | 
                                        Serial: <?php echo $rep['new_serial_no']; ?>
                                        <br>
                                        <small class="text-muted">Date: <?php echo date('d-m-Y', strtotime($rep['replacement_date'])); ?></small>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                                <div class="chain-item current-chain">
                                    <i class="fas fa-arrow-down text-warning"></i>
                                    <div class="chain-box bg-warning bg-opacity-10">
                                        <span class="badge bg-warning">Current Replacement</span>
                                        Will replace: <strong><?php echo $replacementCount > 0 ? end($replacements)['new_model_no'] : $battery['model_type']; ?></strong>
                                        (Serial: <?php echo $replacementCount > 0 ? end($replacements)['new_serial_no'] : $battery['serial_number']; ?>)
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Old Battery Serial Number</label>
                        <input type="text" name="old_serial_no" class="form-control" value="<?php echo $replacementCount > 0 ? end($replacements)['new_serial_no'] : $battery['serial_number']; ?>" readonly>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Old Model Number</label>
                        <input type="text" name="old_model_no" class="form-control" value="<?php echo $replacementCount > 0 ? end($replacements)['new_model_no'] : $battery['model_type']; ?>" readonly>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">New Battery Serial Number *</label>
                        <input type="text" name="new_serial_no" id="new_serial_no" class="form-control" required placeholder="Enter new battery serial number">
                        <small id="new_serial_status"></small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">New Model Number *</label>
                        <input type="text" name="new_model_no" id="new_model_no" class="form-control" required placeholder="Enter new model number">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Dispatch Date</label>
                        <input type="date" name="dispatch_date" class="form-control">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Decision *</label>
                        <select name="decision" class="form-select" required>
                            <option value="Pending">⏳ Pending</option>
                            <option value="FWD to COMPANY">📤 FWD to COMPANY</option>
                            <option value="ONSPOT & FWD TO COMPANY">⚡ ONSPOT & FWD TO COMPANY</option>
                            <option value="FWD TO OTHER COMPANY">🏢 FWD TO OTHER COMPANY</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Query Status *</label>
                        <select name="query_status" class="form-select" required>
                            <option value="Pending">⏳ Pending</option>
                            <option value="Solved">✅ Solved</option>
                            <option value="Return">🔄 Return</option>
                            <option value="Other">❓ Other</option>
                        </select>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Remarks</label>
                        <textarea name="remarks" class="form-control" rows="3" placeholder="Any additional remarks..."></textarea>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Upload Warranty Card/Bill (Max 1MB)</label>
                        <input type="file" name="document_file" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
                        <small class="text-muted">Allowed: PDF, JPG, JPEG, PNG (Max 1MB)</small>
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success btn-lg">
                        <i class="fas fa-save"></i> Save Replacement
                    </button>
                    <a href="replacements.php" class="btn btn-secondary btn-lg">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
$(document).ready(function() {
    // Initialize DataTable for recent records
    if ($('#recentTable').length && !$.fn.DataTable.isDataTable('#recentTable')) {
        $('#recentTable').DataTable({
            order: [[0, 'desc']],
            pageLength: 10,
            language: {
                search: "Search in recent records:",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ entries"
            }
        });
    }
    
    // Mobile number search
    $('#mobileSearch').on('keyup', function() {
        var search = $(this).val();
        if (search.length >= 3) {
            $.ajax({
                url: '../ajax/search_customer.php',
                method: 'GET',
                data: { search: search, type: 'mobile' },
                dataType: 'json',
                success: function(data) {
                    displayResults(data, 'mobileResults');
                },
                error: function() {
                    $('#mobileResults').html('<div class="result-item text-danger">Error loading results</div>').show();
                }
            });
        } else {
            $('#mobileResults').hide();
        }
    });
    
    // General search
    $('#generalSearch').on('keyup', function() {
        var search = $(this).val();
        if (search.length >= 2) {
            $.ajax({
                url: '../ajax/search_customer.php',
                method: 'GET',
                data: { search: search, type: 'general' },
                dataType: 'json',
                success: function(data) {
                    displayResults(data, 'generalResults');
                },
                error: function() {
                    $('#generalResults').html('<div class="result-item text-danger">Error loading results</div>').show();
                }
            });
        } else {
            $('#generalResults').hide();
        }
    });
    
    // Check new serial number uniqueness
    $('#new_serial_no').on('blur', function() {
        var serial = $(this).val();
        if (serial) {
            $.ajax({
                url: '../ajax/check_serial_uniqueness.php',
                method: 'POST',
                data: { serial_number: serial },
                dataType: 'json',
                success: function(response) {
                    if (response.exists) {
                        $('#new_serial_status').html('<span class="text-danger">✗ Serial number already exists!</span>');
                        $('#new_serial_no').addClass('is-invalid');
                    } else {
                        $('#new_serial_status').html('<span class="text-success">✓ Serial number available</span>');
                        $('#new_serial_no').removeClass('is-invalid').addClass('is-valid');
                    }
                }
            });
        }
    });
    
    // Hide results when clicking outside
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.search-box').length) {
            $('.search-results').hide();
        }
    });
});

function displayResults(data, containerId) {
    var container = $('#' + containerId);
    if (data.length > 0) {
        var html = '';
        data.forEach(function(item) {
            var warrantyClass = item.warranty_status == 'Active' ? 'success' : 'danger';
            html += '<div class="result-item" onclick="selectCustomer(' + item.id + ')">';
            html += '<div class="d-flex justify-content-between align-items-center">';
            html += '<div>';
            html += '<strong>' + item.customer_name + '</strong><br>';
            html += '<small>📱 Mobile: ' + item.mobile + '</small><br>';
            html += '<small>🔢 Serial: ' + item.serial_number + '</small>';
            html += '</div>';
            html += '<span class="badge bg-' + warrantyClass + '">' + item.warranty_icon + ' ' + item.warranty_status + '</span>';
            html += '</div>';
            html += '</div>';
        });
        container.html(html).show();
    } else {
        container.html('<div class="result-item">❌ No results found. Try different search term.</div>').show();
    }
}

function selectCustomer(id) {
    window.location.href = 'replacements.php?battery_id=' + id;
}
</script>

<style>
.search-results {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: white;
    border: 1px solid #ddd;
    border-radius: 5px;
    max-height: 300px;
    overflow-y: auto;
    z-index: 1000;
    display: none;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.result-item {
    padding: 12px;
    cursor: pointer;
    border-bottom: 1px solid #eee;
    transition: background 0.2s;
}

.result-item:hover {
    background: #e3f2fd;
}

.search-box {
    position: relative;
}

.timeline-item {
    position: relative;
    padding: 15px;
    margin-bottom: 15px;
    background: #f8f9fa;
    border-radius: 8px;
    border-left: 3px solid #1e3c72;
}

.timeline-item.original {
    border-left-color: #28a745;
    background: #f0fff4;
}

.timeline-item.replacement {
    border-left-color: #ffc107;
}

.replacement-timeline {
    position: relative;
    padding-left: 20px;
}

.replacement-timeline::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #ddd;
}

.timeline-item::before {
    content: '▼';
    position: absolute;
    left: -12px;
    top: 20px;
    font-size: 14px;
    color: #1e3c72;
}

.chain-display {
    padding: 10px;
}

.chain-item {
    margin-bottom: 10px;
    display: flex;
    align-items: flex-start;
    gap: 10px;
}

.chain-item i {
    margin-top: 8px;
}

.chain-box {
    flex: 1;
    padding: 8px 12px;
    background: #f8f9fa;
    border-radius: 6px;
}

.original-chain .chain-box {
    background: #d4edda;
}

.current-chain .chain-box {
    background: #fff3cd;
}

.is-valid {
    border-color: #28a745 !important;
}

.is-invalid {
    border-color: #dc3545 !important;
}

.text-success {
    color: #28a745 !important;
}

.text-danger {
    color: #dc3545 !important;
}

/* Responsive Design */
@media (max-width: 768px) {
    .chain-item {
        flex-direction: column;
    }
    
    .chain-item i {
        transform: rotate(90deg);
        margin: 5px 0;
    }
    
    .timeline-item .row > div {
        margin-bottom: 8px;
    }
}
</style>

<?php require_once '../includes/footer.php'; ?>