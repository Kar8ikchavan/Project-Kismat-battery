<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';
requireLogin();

// Statistics Queries
$totalSold = $pdo->query("SELECT COUNT(*) FROM sold_batteries")->fetchColumn();
$warrantyActive = $pdo->query("SELECT COUNT(*) FROM sold_batteries WHERE warranty_expiry_date >= CURDATE()")->fetchColumn();
$warrantyExpired = $pdo->query("SELECT COUNT(*) FROM sold_batteries WHERE warranty_expiry_date < CURDATE()")->fetchColumn();
$totalReplacements = $pdo->query("SELECT COUNT(*) FROM replacement_history")->fetchColumn();
$pendingClaims = $pdo->query("SELECT COUNT(*) FROM replacement_history WHERE query_status = 'Pending'")->fetchColumn();
$solvedClaims = $pdo->query("SELECT COUNT(*) FROM replacement_history WHERE query_status = 'Solved'")->fetchColumn();
$externalReplacements = $pdo->query("SELECT COUNT(*) FROM external_replacements")->fetchColumn();
$todayEntries = $pdo->query("SELECT COUNT(*) FROM sold_batteries WHERE DATE(created_at) = CURDATE()")->fetchColumn();

// Monthly Sales Data (Kept for potential use but chart removed)
$monthlySales = $pdo->query("
    SELECT DATE_FORMAT(sell_date, '%b') as month, COUNT(*) as count 
    FROM sold_batteries 
    WHERE YEAR(sell_date) = YEAR(CURDATE())
    GROUP BY MONTH(sell_date)
    ORDER BY MONTH(sell_date)
")->fetchAll();

// Company Wise Sales
$companySales = $pdo->query("
    SELECT company, COUNT(*) as count 
    FROM sold_batteries 
    GROUP BY company 
    ORDER BY count DESC 
    LIMIT 5
")->fetchAll();
?>

<div class="container-fluid p-4">
    <h2 class="mb-4"><i class="fas fa-tachometer-alt"></i> Dashboard</h2>
    
    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card card-stats bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Total Batteries Sold</h6>
                            <h2 class="mt-2 mb-0"><?php echo $totalSold; ?></h2>
                        </div>
                        <div class="stat-icon bg-white text-primary">
                            <i class="fas fa-car-battery"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card card-stats bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Warranty Active</h6>
                            <h2 class="mt-2 mb-0"><?php echo $warrantyActive; ?></h2>
                        </div>
                        <div class="stat-icon bg-white text-success">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card card-stats bg-danger text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Warranty Expired</h6>
                            <h2 class="mt-2 mb-0"><?php echo $warrantyExpired; ?></h2>
                        </div>
                        <div class="stat-icon bg-white text-danger">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card card-stats bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Total Replacements</h6>
                            <h2 class="mt-2 mb-0"><?php echo $totalReplacements; ?></h2>
                        </div>
                        <div class="stat-icon bg-white text-info">
                            <i class="fas fa-exchange-alt"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card card-stats bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Pending Claims</h6>
                            <h2 class="mt-2 mb-0"><?php echo $pendingClaims; ?></h2>
                        </div>
                        <div class="stat-icon bg-white text-warning">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card card-stats bg-secondary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Solved Claims</h6>
                            <h2 class="mt-2 mb-0"><?php echo $solvedClaims; ?></h2>
                        </div>
                        <div class="stat-icon bg-white text-secondary">
                            <i class="fas fa-check-circle"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card card-stats bg-dark text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">External Shop</h6>
                            <h2 class="mt-2 mb-0"><?php echo $externalReplacements; ?></h2>
                        </div>
                        <div class="stat-icon bg-white text-dark">
                            <i class="fas fa-store"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card card-stats bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Today's Entries</h6>
                            <h2 class="mt-2 mb-0"><?php echo $todayEntries; ?></h2>
                        </div>
                        <div class="stat-icon bg-white text-success">
                            <i class="fas fa-calendar-day"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- Company Wise Sales with Chart and Table -->
<div class="row mb-4">
    <div class="col-lg-12 mb-3">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-chart-pie"></i> Company Wise Sales</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <canvas id="companySalesChart" height="250"></canvas>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Company Name</th>
                                    <th>Batteries Sold</th>
                                    <th>Percentage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $totalCount = array_sum(array_column($companySales, 'count'));
                                foreach ($companySales as $company): 
                                    $percentage = $totalCount > 0 ? round(($company['count'] / $totalCount) * 100, 1) : 0;
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($company['company']); ?></td>
                                    <td><?php echo $company['count']; ?></td>
                                    <td><?php echo $percentage; ?>%</td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot >
                                <tr style="background-color: #cbced1; font-weight:bold;">
                                    <th>Total</th>
                                    <th><?php echo $totalCount; ?></th>
                                    <th>100%</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

  <!-- Warranty Status Summary -->
<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-shield-alt"></i> Warranty Status Summary</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <canvas id="warrantyChart" height="200"></canvas>
                    </div>
                    <div class="col-md-6">
                        <div class="alert alert-success">
                            <strong>🟢 Active Warranty </strong>
                        </div>
                        <div class="alert alert-danger">
                            <strong>🔴 Expired Warranty:</strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-chart-pie"></i> Warranty Distribution</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive" style="border:collapse;">
                  <style>
    .black-border-table,
    .black-border-table th,
    .black-border-table td {
        border: 2px solid #000 !important;
        border-collapse: collapse;
    }
</style>

<table class="table black-border-table">
    <thead>
        <tr>
            <th>Warranty Status</th>
            <th>Number of Batteries</th>
            <th>Percentage</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>🟢 Active Warranty</td>
            <td><?php echo $warrantyActive; ?></td>
            <td>
                <?php 
                $totalWarranty = $warrantyActive + $warrantyExpired;
                $activePercent = $totalWarranty > 0 ? round(($warrantyActive / $totalWarranty) * 100, 1) : 0;
                echo $activePercent; ?>%
            </td>
        </tr>
        <tr>
            <td>🔴 Expired Warranty</td>
            <td><?php echo $warrantyExpired; ?></td>
            <td>
                <?php 
                $expiredPercent = $totalWarranty > 0 ? round(($warrantyExpired / $totalWarranty) * 100, 1) : 0;
                echo $expiredPercent; ?>%
            </td>
        </tr>
    </tbody>
    <tfoot style="background-color: #cbced1; font-weight:bold;">
        <tr>
            <th>Total</th>
            <th><?php echo $totalWarranty; ?></th>
            <th>100%</th>
        </tr>
    </tfoot>
</table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Monthly Sales Chart - REMOVED

// Company Sales Chart
const companyCtx = document.getElementById('companySalesChart').getContext('2d');
const companyData = <?php echo json_encode(array_column($companySales, 'count')); ?>;
const companyLabels = <?php echo json_encode(array_column($companySales, 'company')); ?>;

new Chart(companyCtx, {
    type: 'pie',
    data: {
        labels: companyLabels,
        datasets: [{
            data: companyData,
            backgroundColor: ['#1e3c72', '#28a745', '#ffc107', '#dc3545', '#17a2b8']
        }]
    }
});

// Warranty Chart
const warrantyCtx = document.getElementById('warrantyChart').getContext('2d');
new Chart(warrantyCtx, {
    type: 'doughnut',
    data: {
        labels: ['Active Warranty', 'Expired Warranty'],
        datasets: [{
            data: [<?php echo $warrantyActive; ?>, <?php echo $warrantyExpired; ?>],
            backgroundColor: ['#28a745', '#dc3545']
        }]
    }
});
</script>

<?php
require_once '../includes/footer.php';
?>