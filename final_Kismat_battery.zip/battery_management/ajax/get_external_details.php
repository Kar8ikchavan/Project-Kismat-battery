<?php
require_once '../config/database.php';
header('Content-Type: text/html');

if (!isset($_SESSION['admin_id'])) {
    echo '<div class="alert alert-danger">Unauthorized</div>';
    exit();
}

$id = $_GET['id'] ?? 0;

$stmt = $pdo->prepare("SELECT * FROM external_replacements WHERE id = ?");
$stmt->execute([$id]);
$data = $stmt->fetch();

if (!$data) {
    echo '<div class="alert alert-danger">Record not found</div>';
    exit();
}
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-6 detail-row">
            <div class="detail-label">Customer Name:</div>
            <div><?php echo htmlspecialchars($data['customer_name']); ?></div>
        </div>
        <div class="col-md-6 detail-row">
            <div class="detail-label">Mobile Number:</div>
            <div><?php echo $data['mobile']; ?></div>
        </div>
        <div class="col-md-6 detail-row">
            <div class="detail-label">Battery Type:</div>
            <div><?php echo $data['battery_type'] ?: '-'; ?></div>
        </div>
        <div class="col-md-6 detail-row">
            <div class="detail-label">Company:</div>
            <div><?php echo $data['company'] ?: '-'; ?></div>
        </div>
        <div class="col-md-6 detail-row">
            <div class="detail-label">Model Number:</div>
            <div><?php echo $data['model_type'] ?: '-'; ?></div>
        </div>
        <div class="col-md-6 detail-row">
            <div class="detail-label">Serial Number:</div>
            <div><strong><?php echo $data['serial_number'] ?: '-'; ?></strong></div>
        </div>
        <div class="col-12 detail-row">
            <div class="detail-label">Warranty Details:</div>
            <div><?php echo nl2br(htmlspecialchars($data['warranty_details'] ?: '-')); ?></div>
        </div>
        <div class="col-12 detail-row">
            <div class="detail-label">Problem Description:</div>
            <div><?php echo nl2br(htmlspecialchars($data['problem_description'] ?: '-')); ?></div>
        </div>
        <div class="col-12 detail-row">
            <div class="detail-label">Replacement Notes:</div>
            <div><?php echo nl2br(htmlspecialchars($data['replacement_notes'] ?: '-')); ?></div>
        </div>
        <div class="col-12 detail-row">
            <div class="detail-label">Date:</div>
            <div><?php echo date('d-m-Y h:i A', strtotime($data['created_at'])); ?></div>
        </div>
        <?php if($data['bill_file']): ?>
        <div class="col-12 detail-row">
            <div class="detail-label">Bill File:</div>
            <div>
                <a href="../assets/uploads/<?php echo $data['bill_file']; ?>" target="_blank" class="btn btn-sm btn-info">
                    <i class="fas fa-download"></i> Download Bill
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.detail-row {
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}
.detail-label {
    font-weight: bold;
    color: #1e3c72;
    margin-bottom: 5px;
}
</style>