<?php
require_once '../config/database.php';
header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$battery_id = $_GET['battery_id'] ?? 0;

if (!$battery_id) {
    echo json_encode(['error' => 'No battery ID provided']);
    exit();
}

// Get original battery
$stmt = $pdo->prepare("SELECT * FROM sold_batteries WHERE id = ?");
$stmt->execute([$battery_id]);
$battery = $stmt->fetch();

if (!$battery) {
    echo json_encode(['error' => 'Battery not found']);
    exit();
}

// Get all replacements
$stmt = $pdo->prepare("SELECT * FROM replacement_history WHERE battery_id = ? ORDER BY replacement_no ASC");
$stmt->execute([$battery_id]);
$replacements = $stmt->fetchAll();

$response = [
    'original' => [
        'model' => $battery['model_type'],
        'serial' => $battery['serial_number'],
        'date' => $battery['sell_date'],
        'company' => $battery['company']
    ],
    'replacements' => $replacements,
    'count' => count($replacements)
];

echo json_encode($response);
?>