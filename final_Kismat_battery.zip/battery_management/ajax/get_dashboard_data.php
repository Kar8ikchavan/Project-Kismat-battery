<?php
require_once '../config/database.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    exit(json_encode(['error' => 'Unauthorized']));
}

$action = $_GET['action'] ?? '';

if ($action == 'stats') {
    $totalSold = $pdo->query("SELECT COUNT(*) FROM sold_batteries")->fetchColumn();
    $warrantyActive = $pdo->query("SELECT COUNT(*) FROM sold_batteries WHERE warranty_expiry_date >= CURDATE()")->fetchColumn();
    $totalReplacements = $pdo->query("SELECT COUNT(*) FROM replacement_history")->fetchColumn();
    $pendingClaims = $pdo->query("SELECT COUNT(*) FROM replacement_history WHERE query_status = 'Pending'")->fetchColumn();
    
    echo json_encode([
        'total_sold' => $totalSold,
        'warranty_active' => $warrantyActive,
        'total_replacements' => $totalReplacements,
        'pending_claims' => $pendingClaims
    ]);
} elseif ($action == 'monthly_sales') {
    $data = $pdo->query("
        SELECT DATE_FORMAT(sell_date, '%b') as month, COUNT(*) as count 
        FROM sold_batteries 
        WHERE YEAR(sell_date) = YEAR(CURDATE())
        GROUP BY MONTH(sell_date)
        ORDER BY MONTH(sell_date)
    ")->fetchAll();
    
    echo json_encode($data);
}
?>