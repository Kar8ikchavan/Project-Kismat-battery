<?php
require_once '../config/database.php';
header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$search = $_GET['search'] ?? '';
$type = $_GET['type'] ?? 'general';

if (strlen($search) < 2) {
    echo json_encode([]);
    exit();
}

if ($type == 'mobile') {
    $stmt = $pdo->prepare("SELECT id, customer_name, mobile, serial_number, battery_type, company, warranty_expiry_date FROM sold_batteries WHERE mobile LIKE ? ORDER BY id DESC LIMIT 10");
    $stmt->execute(["%$search%"]);
} else {
    $stmt = $pdo->prepare("SELECT id, customer_name, mobile, serial_number, battery_type, company, warranty_expiry_date FROM sold_batteries WHERE customer_name LIKE ? OR serial_number LIKE ? OR ticket_no LIKE ? ORDER BY id DESC LIMIT 10");
    $stmt->execute(["%$search%", "%$search%", "%$search%"]);
}

$results = $stmt->fetchAll();

foreach($results as &$row) {
    $warranty = getWarrantyStatus($row['warranty_expiry_date']);
    $row['warranty_status'] = $warranty['status'];
    $row['warranty_icon'] = $warranty['icon'];
    $row['warranty_class'] = $warranty['class'];
}

echo json_encode($results);
?>