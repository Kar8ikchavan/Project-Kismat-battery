<?php
require_once '../config/database.php';
header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['exists' => false]);
    exit();
}

$serial_number = $_POST['serial_number'] ?? '';

if (empty($serial_number)) {
    echo json_encode(['exists' => false]);
    exit();
}

// Check in sold_batteries
$stmt = $pdo->prepare("SELECT COUNT(*) FROM sold_batteries WHERE serial_number = ?");
$stmt->execute([$serial_number]);
$count1 = $stmt->fetchColumn();

// Check in replacement_history
$stmt = $pdo->prepare("SELECT COUNT(*) FROM replacement_history WHERE new_serial_no = ?");
$stmt->execute([$serial_number]);
$count2 = $stmt->fetchColumn();

echo json_encode(['exists' => ($count1 + $count2) > 0]);
?>