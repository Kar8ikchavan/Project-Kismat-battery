<?php
require_once '../config/database.php';
header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$battery_id = $_GET['battery_id'] ?? 0;

if (!$battery_id) {
    echo json_encode(['error' => 'No battery ID provided']);
    exit();
}

// Get original battery
$stmt = $pdo->prepare("SELECT * FROM sold_batteries WHERE id = ?");
$stmt->execute([$battery_id]);
$battery = $stmt->fetch();

if (!$battery) {
    echo json_encode(['error' => 'Battery not found']);
    exit();
}

// Get all replacements
$stmt = $pdo->prepare("SELECT * FROM replacement_history WHERE battery_id = ? ORDER BY replacement_no ASC");
$stmt->execute([$battery_id]);
$replacements = $stmt->fetchAll();

$replacementCount = count($replacements);
$nextReplacementNo = $replacementCount + 1;

// Get last replacement or original
if ($replacementCount > 0) {
    $lastReplacement = $replacements[$replacementCount - 1];
    $oldModel = $lastReplacement['new_model_no'];
    $oldSerial = $lastReplacement['new_serial_no'];
} else {
    $oldModel = $battery['model_type'];
    $oldSerial = $battery['serial_number'];
}

// Build replacement chain for display
$chain = [
    'original' => [
        'model' => $battery['model_type'],
        'serial' => $battery['serial_number']
    ]
];

foreach($replacements as $idx => $rep) {
    $chain[($idx+1) . 'st'] = [
        'model' => $rep['new_model_no'],
        'serial' => $rep['new_serial_no']
    ];
}

$response = [
    'battery_id' => $battery_id,
    'customer_name' => $battery['customer_name'],
    'mobile' => $battery['mobile'],
    'battery_type' => $battery['battery_type'],
    'company' => $battery['company'],
    'old_model' => $oldModel,
    'old_serial' => $oldSerial,
    'replacement_no' => $nextReplacementNo,
    'replacement_count' => $replacementCount,
    'replacement_chain' => $chain,
    'replacement_no_formatted' => formatReplacementNumber($nextReplacementNo)
];

echo json_encode($response);
?>