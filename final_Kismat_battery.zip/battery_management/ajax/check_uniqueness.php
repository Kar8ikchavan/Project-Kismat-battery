<?php
require_once '../config/database.php';
header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['exists' => false, 'message' => 'Unauthorized']);
    exit();
}

$field = $_POST['field'] ?? '';
$value = $_POST['value'] ?? '';

if (empty($field) || empty($value)) {
    echo json_encode(['exists' => false, 'message' => 'Invalid request']);
    exit();
}

$exists = false;
$message = '';

// Check in sold_batteries table
if ($field == 'serial_number') {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM sold_batteries WHERE serial_number = ?");
    $stmt->execute([$value]);
    $count = $stmt->fetchColumn();
    
    if ($count > 0) {
        $exists = true;
        $message = 'Serial number already exists in system';
    } else {
        $message = 'Serial number is available';
    }
} 
elseif ($field == 'ticket_no') {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM sold_batteries WHERE ticket_no = ?");
    $stmt->execute([$value]);
    $count = $stmt->fetchColumn();
    
    if ($count > 0) {
        $exists = true;
        $message = 'Ticket number already exists in system';
    } else {
        $message = 'Ticket number is available';
    }
}
elseif ($field == 'model_type') {
    // Check if model type with same serial exists
    $serial = $_POST['serial'] ?? '';
    if ($serial) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM sold_batteries WHERE model_type = ? AND serial_number = ?");
        $stmt->execute([$value, $serial]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            $exists = true;
            $message = 'Model-Serial combination already exists';
        } else {
            $message = 'Model type is available';
        }
    } else {
        $message = 'Model type is available';
    }
}

echo json_encode(['exists' => $exists, 'message' => $message]);
?>