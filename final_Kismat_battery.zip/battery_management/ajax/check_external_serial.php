<?php
require_once '../config/database.php';
header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['exists' => false]);
    exit();
}

$serial_number = $_POST['serial_number'] ?? '';

if (empty($serial_number)) {
    echo json_encode(['exists' => false]);
    exit();
}

$stmt = $pdo->prepare("SELECT COUNT(*) FROM external_replacements WHERE serial_number = ?");
$stmt->execute([$serial_number]);
$count = $stmt->fetchColumn();

echo json_encode(['exists' => $count > 0]);
?>